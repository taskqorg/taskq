# Task #2433 verification

Candidate: `8e470d22c39a42686c9a0bdc14bd42bf00824c93`. Baseline: `c54ce74d6665735d905e18064cc9739b41d2364d`.
Task: https://github.com/taskqorg/taskq/issues/2433. PR: https://github.com/taskqorg/taskq/pull/2484.

R13 and Product: the root contract and Conversations detail define the shared row-key anchor and task-thread behavior. R1: native history remains its source; no transcript database, parser or scrolling library was added. R12: portable, browser and native evidence below have separate scopes. Section 7: this is a worker handoff; publication still requires green merge-result CI.

| Acceptance | Evidence |
|---|---|
| A1-A2 | Root contract and AI workspace detail; the offset-owner check finds 40 violations in the baseline and zero in the candidate. The native capture harness is the named exception. |
| A3-A4 | `node tests/scroll-anchor.browser.cjs`: all 42 surface/cause pairs, seven forced-drift cases, explicit cause telemetry, focus, selection and Back pass. The 2 CSS px and 250 ms assertions remain. |
| A5-A6 | Thread, centre and checkpoint browser checks cover open/closed tasks, several attempts, chronological board/native records, visible source failures, inline lazy images, paged logs and exact targets. An old board target reads at most one live-tail page instead of scanning the log. |
| A7 | Local-first/background-refresh cases, cold/warm and restored-selection checks pass. `profile-action.txt` is the actual native `taskq profile actions` row: one cold snapshot open, 25 ms for this fixture, without a latency ceiling. |
| A8 | Browser checks retain live-worker message and closed/reviewer refusal boundaries. Native macOS checks retain position, focus and selection in both themes; see the two images and JSON. Windows native: Not tested. |

## Checks

- `python3 scripts/check.py --base c54ce74d6665735d905e18064cc9739b41d2364d`: sandbox-blocked, not PASS. On this candidate: 1091 unit tests passed, seven protected-app-server fixtures failed with PermissionDenied while writing protected fixture configuration, 48 were ignored. Elapsed: 125.784 s of 900 s. No guard was weakened.
- All 43 Node component checks and all nine changed browser instruments passed, including Chromium/WebKit where those instruments support both.
- `cargo test --locked --bin taskq tray::tests`: 65 passed, one ignored.
- Offline selftest passed; board reads and external tool probes were explicitly unknown because offline mode was set. It used an isolated fixture installation.
- Contract lint and Rust/JS/CSS formatting passed. Existing COMPACT target warnings remain.
- macOS 27.2 arm64, Node 22.18.0, Playwright 1.64.1, rustc/cargo 1.98.1; warm build cache. Native checkpoint used the signed candidate through Cargo.

## Failure before, protection after

- Inline previews mounted six images after the previous implementation removed the old guard. The reader now retains four previews and a shared 2 MiB bound; other retained images remain reachable. Both bounds and image switching are checked.
- An exact old board-event jump timed out and scanned all earlier native pages. Native-source boundaries now own paging; the 4096-record case passes with the exact-target, focus, selection and 2 CSS px protections retained.
- Restoring a selected thread emitted no open metric. The new regression check failed with an empty action list, then passed with one cold snapshot action and no extra redraw action; the native profile command reads that action too.
- Off-screen/occluded WebKit delivered timers without animation frames. The checkpoint fixture now remains visible and unoccluded without taking focus, and capture waits for its exact step receipt. Missing completion still fails and stale steps cannot qualify a capture.
- Scroll fixtures assumed queued input had already arrived or kept scrolling after a valid update. They now observe input and quiet, compare painted rows and enqueue data during the final settling input. Drift, timing, telemetry and native-wheel checks remain.
- The published PR failed Rust formatting. The candidate passes the same formatting check.

## Limits

The bounded-block table case injects a fixture because current renderers emit no bounded block. Native captures use invented IPC and qualify the native renderer, not live provider/board delivery, production installation or deployment. Windows native remains Not tested. The seven host tests remain sandbox-blocked. Merge-group CI is pending reviewer publication; no merge or close was performed.
