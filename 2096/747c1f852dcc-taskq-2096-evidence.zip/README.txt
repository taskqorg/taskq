TaskQ #2096 Settings correction
Start with index.html. report.md records requirements, proof and limits.
Screens use the same invented fixture at 320x960, 18px, dark theme.
Three before screens use clean 4bbce5e2; seven after screens use the source/build hashes in identity.json.
The matrix covers both themes, 18/20px and 320/560px.
No native/live acceptance, deployment, restart, grants or real messages are claimed.
