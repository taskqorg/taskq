# Retained #2427 Windows commits

This is the transfer artifact for https://github.com/taskqorg/taskq/issues/2443.
It preserves the existing A1-A6 work and partial A7 for the receiving #2427 attempt.
No implementation, rebase, runtime probe, tag publication or host-policy change was performed.

## Identity and preservation (A1, A2; R2, R12)

- Source ref: `refs/heads/taskq-2427`.
- Base and bundle prerequisite: `96064118e637ea8d7347edc4ca50c5c5da186757`.
- Tip: `875935ed1232c1d4d19223531e0e3810f4fa05c7`.
- Commits beyond the base: 13, listed oldest first in `commits.txt`.
- Source dirty state: clean before and after export.
- Source branch, index bytes and all 676 tracked/nonignored working-file contents matched before and after. No source files were written; ignored files were not modified or hashed.
- Bundle: 1016626 bytes; SHA-256 `62017da54cd30f6092c1cf08097fbc2b15edfac11eaae13764e4b469a0474d3f`.
- The result SHA for #2443 identifies its unchanged baseline, not the bundled refactor candidate. This artifact does not submit #2427 for publication.

## Fetch into the existing Mac worktree (A3; R2)

Download the result ZIP, place it in the existing `taskq-2427` worktree and extract it to a new `transfer-2443` directory.
The base is an ancestor of the reported Mac baseline `2701721e8d769ae9d99ed711b7c3777f7c7e83af`.
Run these commands from that worktree. The fetch creates a separate ref and leaves the local branch and working files unchanged.

```sh
set -eu
unzip taskq-2427-win-handoff.zip -d transfer-2443
(cd transfer-2443 && shasum -a 256 -c SHA256SUMS)
test "$(git symbolic-ref --short HEAD)" = taskq-2427
test "$(git rev-parse HEAD)" = 2701721e8d769ae9d99ed711b7c3777f7c7e83af
git bundle verify transfer-2443/taskq-2427-win.bundle
git fetch --no-tags transfer-2443/taskq-2427-win.bundle refs/heads/taskq-2427:refs/remotes/win-handoff/taskq-2427
test "$(git rev-parse refs/remotes/win-handoff/taskq-2427)" = 875935ed1232c1d4d19223531e0e3810f4fa05c7
git log --reverse --format='%H %s' 96064118e637ea8d7347edc4ca50c5c5da186757..refs/remotes/win-handoff/taskq-2427
```

The 13 original commits are then available at `refs/remotes/win-handoff/taskq-2427`.
The retained tip and the Mac baseline have diverged, so fetching does not fast-forward the local branch. Adoption for continued implementation belongs to the receiving #2427 attempt; this transfer performs no merge, reset or rebase.

## Verification and limits (R5, R12)

`verification.txt` records an isolated Git receiver seeded only from the exact Mac baseline.
Before fetch the retained tip was absent. `git bundle verify`, fetch, full object/connectivity verification and comparison of all 13 commit identities passed. The receiver's original `taskq-2427` ref remained at the Mac baseline.
This proves a portable Git handoff, not execution on the actual Mac host or runtime qualification.
No code changed, so application tests and CI were not run.

## Accepted continuation scope

#2427 remains the source of accepted decisions and task notes.
A1-A6 are retained; A7's data-only Adapter part is committed, while launch adoption and native evidence remain unfinished. A8 follows A7.
The accepted AgentQ-first decision and probe approval remain on #2427; PM-owned `runtime-v0.5.0` tag publication remains separate. This transfer changes none of those decisions and makes no current tag-status claim.
