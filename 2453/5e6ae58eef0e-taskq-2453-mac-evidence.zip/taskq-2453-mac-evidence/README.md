# #2453 Mac evidence for #2427 A7

Candidate: bundle tip 0af92c03ef58b69b3f0971369517f4f6376eb5e7 from the #2451 archive. No Git object, branch or service changed.
Machine data: summary.json. Raw native logs stay out; each has a SHA-256 in summary.json.

## A1 Archive
Archive SHA-256 a1e098f17514cf3e7a092ee3d6285a7204a36e35f23c37de52e0f85d3734bfc6 matches; 1031183 bytes.
Bundle SHA-256 da3c1fabddcbcc8316b1ccbf9b24c91806943fc6895b5e45fbc7513fa6eb5fbe matches. git bundle verify passed, prerequisite 96064118.
Isolated fetch kept tip 0af92c03 and the 16 original commit SHAs; fsck is clean. The Mac taskq-2427 branch stays at 2701721e.

## Gap 1: exact tip does not build on macOS
exact-tip-macos-build-errors.txt holds both errors (service_cmd.rs:52 icon path; service_run.rs:455 Result type).
All evidence here comes from the tip plus mac-compile-overlay.patch (2 lines). #2427 owns the source fix and must commit this or an equal fix, then keep the affected evidence valid under R12. These binaries are not the exact tip.

## A2 Native start and resume
No Mac PM receipt for #2427 existed, so these turns are new. Instrument: native_trait_start_resume_and_transcript from the candidate, artifact 7a2ba9002ad98d8af50a611c64bc331207f3ee73ab462ca20157f410454e4902.
Claude, Codex, codex-app and Antigravity each passed two bounded turns: start, resume, same session, exact input accepted, fresh canary in the native transcript and in the TaskQ transcript.
Exit: Claude 0, codex-app 0. Codex and Antigravity -1, after the native turn end, because TaskQ stops the lingering owned process. Windows records the same -1 for Antigravity.

## A3 Observation through status and heartbeat
Instrument: native_service_observation_2453 (service-observation-instrument.patch, temporary, not in #2427). It runs the candidate Service pass on a fixture board with a real native client and one real bounded turn.
Each runtime reached a running execution row in local status and in heartbeat readback, then a released Exit, with no second launch. Local status and heartbeat rows are equal apart from observation times and process_id.
Boundary (R12): fixture board and in-process Service. This is not installed-service evidence.

Two instrument assertions failed on the first runs and did not reflect runtime behavior:
- Codex (v1): the comparison included process_id. The local status row has it and the heartbeat row does not. Captured rows were rechecked with v2 and are equal; the turn was not replayed.
- codex-app: the check read the launcher log, which holds only the handshake. The canary is in the native rollout (hash in summary.json); the turn was not replayed. Its test result stays FAILED in runs/codex-app-service.txt.

Limits named:
- Installed service: installed-readback.txt shows 4.6.84-261105-1 on Mac, not the candidate. No installed-service claim is made for the candidate; no production service changed.
- The installed heartbeat reads back only runtimes that had live workers; Antigravity and codex-app had none. An earlier heartbeat in this run also reported codex-app as "codex-app not in has", so the installed Mac service would not admit it.
- codex-app: no process identity or process_id, and progress stays unknown ("no supported native progress event").
- Claude: the reported process started before this launch and was gone after the turn. The cause (probably a prepared Claude daemon process) is not verified.
- Claude: state went to unknown between native exit and release.
- Fixture trace execution_heartbeat_is_fenced passed for four runtimes on Mac; it is fixture evidence only (fixture-heartbeat.txt). Its strict row equality cannot see the process_id difference, since a fake process reports none.

## Gap 2: Mac runtime tests depend on the environment
runtime:: on Mac: 136 passed, 2 failed with the probe environment; 138 passed, 0 failed, 17 ignored with all three conditions below (runtime-suite-final.txt). The failing tests are trait_launch_preserves_input_policy_environment_and_exit and background_trait_retains_launcher_output_and_saved_session.
- The tests call which("python"); a stock Mac has only python3. A temporary symlink named python was used.
- A TMPDIR under /tmp fails with "native baseline unavailable", probably because /tmp is a symlink on macOS. Canonical /private/tmp passes.
- With AGENTQ_LAUNCHER cleared, one test fails because it expects AGENTQ_LAUNCHER=taskq; the run inherited that value from the worker environment. Cause not traced further.
These are test defects, not native failures. #2427 owns any fix and its canonical gate must pass on Mac.

## A4 Authority and preservation
Grants were read at each launch; policy revision 34 (permissions-before.txt). Claude: legacy, no grant. Codex: workspace. codex-app: full, uncontained, owner grant. Antigravity: workspace.
worker-policy.json and host.json hashes are unchanged after all runs. No grant, login or policy changed.
Paid approval: #2427 note 6664768263. 12 short turns in total, bounded at 180 seconds each. No uncertain input was replayed; each turn has its own canary.
The ChatGPT app processes kept the same PIDs. Unrelated sessions were not stopped.
Cleanup: 3 probe input files were removed from the registered project .taskq/inputs folder. They were found by their canary. Native sessions named TaskQ Qualification stay in the clients' own history.
