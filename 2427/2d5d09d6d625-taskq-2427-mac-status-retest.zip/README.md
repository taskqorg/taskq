# Mac status/heartbeat retest for TaskQ #2427

Candidate: 5d67515a7152fa7fd6f7edab4271cd4212aa0451. Retained reviewer scratch instrument binary SHA256: 138a28462814e12baaec679713c8501eee376d1f2497af67a28cfbbfecadd133. Instrument patch SHA256: fbe873e3f3de4649356c3ac99f6edfabea4679d3e19f4a739f7e38fc3b1df879. Source provenance: task2427 comment6676512120; same binary hash read back before this run. Test-only instrument on candidate Service with fixture board; native clients are real. No installed service qualification.

Authority: owner note6664768263, local PM operator. TaskQ installed permissions revision34 read immediately before launch; each native launch also resolves access through runtime::access. Policy and host hashes matched before every turn and afterward. No permissions, login, SSH, service or board configuration changes.

One fresh canary turn per runtime, no resumes/replays, each bounded180s. Exact test: service::tests::native_service_observation_2453 --ignored --nocapture. Claude6/6, Codex8/8, Codex-app12/12, Antigravity10/10 equal status/heartbeat reads; all unequal arrays empty, including read1. Each launches=1, native and TaskQ reply true, release Exit. Four tests exit0.

Comparison strips only the retained instrument timestamp/process-id fields. Native start/resume/exact-input evidence remains retained from #2462; this retest qualifies only invalidated A2 parity. Windows Antigravity exact-input gap #2463, no-PR publication decision #2466, installed service, real board transport, containment, telemetry and merge-result CI remain separate and unqualified. Raw native transcripts are not included. Session identities are hashed and local home/temp paths are redacted.
