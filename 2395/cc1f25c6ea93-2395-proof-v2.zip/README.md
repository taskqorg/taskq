# TaskQ #2395 offline replay proof handoff

Prepared only: full canonical gate remains PENDING. No production or release ref
was changed. This attachment is public source evidence, not runtime qualification.

Reviewed prerequisite: d82957095f9e8c2117ac56f64dbd1f4c2e1a0c29
Replay head: cc7941f4d4db1d2f50e7ce95f5d59733210654f1
Expected tree (both heads): 7300a5b79d6e0f5851990887bde393e722b62666
Experimental base: 437b96ac58375c3dab9c3c9966114832bd2ae503
Bundle SHA-256: 05b135ef04e4813eb13bc49b3e502df0687704836b4b5db9d5f5dc5957679b52
Canonical inputs SHA-256: 06d1dfd38f512508626900a1b209ecd95d05896fecdca19ef01aeef60dff46e3
Proof manifest SHA-256: 2d4b0819473edcba93fb6f4d437f9a7671a0d523df1dc190c556f88a5fca43dc
Producer revision: 7d0f8ef593cf7ad33352484439decda317334a25
Producer executable SHA-256: 966a23b5f602e49b55ef376480a5ad53ed84d58b2a74bbba274f298de916bc33
Pilot tool SHA-256: 39df5da18bacdcac51f398506b7a1f6287bfa5d888a0aa4e6b5e7d6155277c83

Three authoritative accepted results and six exact Git replay orders produced the
same reviewed tree. Original PR bases stay unknown. No publication events were
backfilled. The two replay commits retain the source as their bundle prerequisite
and the accepted task URLs as Task trailers for the unchanged rule gate.

Operator procedure, in an authorized full TaskQ checkout containing the reviewed
prerequisite; extract this archive beside it, without overwriting checkout files:

1. Verify SHA256SUMS and `git bundle verify /exact/extracted/pilot.bundle`.
2. Fetch only this private proof history:
   `git fetch --no-tags /exact/extracted/pilot.bundle refs/heads/pilot:refs/heads/proof-2395-cc7941f4d4db`
3. Verify the fetched head is exactly the replay SHA above, verify both tree IDs,
   and run `git diff --exit-code d82957095f9e8c2117ac56f64dbd1f4c2e1a0c29 cc7941f4d4db1d2f50e7ce95f5d59733210654f1 --`.
4. As the authorized operator, publish only the unique non-release proof ref:
   `git push origin refs/heads/proof-2395-cc7941f4d4db`
5. Dispatch the unchanged workflow: `gh workflow run tests.yml --ref proof-2395-cc7941f4d4db`.
   workflow_dispatch already sets CHECK_FULL and runs Linux, macOS, Windows and
   Windows GNU protection. No workflow edit or release is requested.
6. Return exact run ID, run_attempt, head SHA, event and conclusion; attempt-specific
   jobs JSON including plan, all three rust jobs, windows-gnu, shots and tests;
   log archive digest, runner/tool versions and elapsed observations where available.
   Missing evidence remains unknown. Do not substitute another SHA or an earlier
   run attempt. Retain the original failed batch if any job fails.

The worker will verify this proof before qualifying the replay gate. Feature PR
and merge_group gates remain separate and required. Once the complete exact-SHA
matrix is verified, do not duplicate the local replay Windows gate. The pilot tool
itself publishes nothing and never qualifies an installed runtime.
