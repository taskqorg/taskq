# Windows execution 6680828219: diagnosis

Task: https://github.com/taskqorg/taskq/issues/2482

## Question

Why does execution 6680828219 still block task 2463 reviewer admission after result 6681009909, and can it be reconciled without replacing the result or starting another executor?

## Final readback

**The original execution was released during this read-only investigation.** Native job `d2a1c0f0` became `stopped` at `2026-11-06T09:30:43.567Z`. Windows no longer reports PID 21628. Board comment [6681722157](https://github.com/taskqorg/taskq/issues/2463#issuecomment-6681722157) records `released 6680828219 exit attempt 6680828219`, operation `release-6680828219`. The service then admitted reviewer 6681723539. The original result SHA remains ee39a45, and the latest local task row has no execution wait for 6680828219. This investigation submitted no stop, release, replay, restart, requeue, reviewer launch or reconciliation command.

The ordinary service retirement path therefore supplied the supported reconciliation. The evidence below preserves the earlier blocked state rather than replacing it with the later success. Before/after readbacks are in separate JSON files. The precise reason the history scan eventually completed is not exposed, so it remains unknown. No source fix is claimed.

## Findings before automatic reconciliation

The exact original Claude process is live, its native turn has completed, and its board execution remains unreleased. TaskQ's native-history observation is pending. A result and a terminal turn do not prove that the native background process exited (R12, section 3).

1. **Original process: live.** Windows reports PID 21628, `claude.exe`, creation FILETIME `134384280522321947`, started `2026-11-06T08:40:52.2321947Z`. This exactly matches the protected recovery row for task 2463 / attempt and execution 6680828219. This is identity evidence, not a process-name inference. The row has input offset 0 and runtime `claude`; Windows CLI Job Object recovery rules for Codex are not a substitute for this Claude background observer.
2. **Native turn: completed; background process: idle/blocked.** Native `agents --json --all --cwd <project>` returns exactly one matching job `d2a1c0f0`, session `d2a1c0f0-8f74-4348-a8b9-c9191d02bfe1`, PID 21628, status `idle`, state `blocked`. The matching session registration agrees. The job reports zero in-flight tasks and queued inputs. Its timeline last changed to blocked at `2026-11-06T08:52:03.063Z` because evidence close awaited authorization and task 2480. That job reason is separate from the native-execution fence.
3. **Attributable input and terminal evidence.** The exact submitted input is a native user message on transcript line 12. The same native session records `system/turn_duration` on line 385 at `2026-11-06T08:52:23.937Z`, duration 690609 ms. The launch record named requested session `6536b3f2-f92d-4b33-ba0a-f7a8c844f09c`; its recorded `thread.started` and actual native readback identify the different session above. Neither identity was invented or changed by this investigation. The TaskQ attempt log does not contain the native terminal record; the retained native transcript does.
4. **Board acceptance exists; release does not.** Spawn/intent is comment 6680828219. Comment 6680862525 is `accepted 6680828219 attempt 6680828219`, operation `accept-6680828219`. Result 6681009909 preserves `ee39a45cdaf50f9ebc9d4de3c9a8fc92118b2e34`. No matching `released ... exit|no-start` comment was observed. Task 2463 is in review with no current worker/reviewer attempt. It is the previous worker's unresolved execution, not a newly running reviewer, that fences admission.
5. **Lease is ownership, not progress.** Host heartbeat issue 745 still carries `#2463 6680828219`. Its matching execution projection says `running / worker process observed`, while progress is unknown. The local service child row says `live: unknown` with `Claude native history scan pending; retry observation without submission`. These are different observation boundaries and timestamps, retained separately in `observations.json`; the lease cannot override missing release. The local task row explicitly exposes termination unconfirmed and a reboot recovery suggestion. No reboot was performed or recommended within this scope.
6. **Service retry intent is not successful termination.** The owning service log repeatedly records `#2463 worker pid 21628 alive after result; stopping` from 08:54 through 09:17 UTC. The process and native state remain as above; the word `stopping` proves no successful native stop. The service is version 4.6.89. Its heartbeat binds the running binary to source `fcd59963daad8686abba192df1557224ed2b0e9c`, digest `94850ae04018333d8b96dbfe70d26160a2bdfe6c09e4bdce509407f02b4c786b`.

## Observation and reconciliation boundary

Read-only observation used the task inbox/issue, the matching local status row and protected identity row, the exact native job/session/transcript, and the owning service's bounded target log lines. Raw logs, native provider environment, credentials, unrelated sessions and local absolute paths are not included.

At the recorded source, `ClaudeHistory::read` returns the observed pending error when `NativeHistory::read` reports an incomplete scan (`src/runtime.rs:3403`). `NativeHistory::lines` keeps its cursor and returns incomplete at an observation deadline, an 8 MiB read budget, or a changing EOF (`src/runtime.rs:4796`). The observed native transcript is 2474504 bytes, with a largest line of 168820 bytes and its terminal record at the end. It fits below the 8 MiB limit. Deadline starvation is a plausible explanation for the persistent pending scan, but the service exposes no exact in-memory cursor/deadline receipt, so the underlying stall mechanism remains unproved. No instrumentation, build or execution replay was added to test it.

The source calls `recover_job` before observing or stopping a Claude turn (`src/runtime.rs:3963`, `:3997`); that recovery itself may require the same history scan (`:3691`). A pending scan therefore prevents this path from reaching native stop/readback. The service retains the child when stop or exit readback fails (`src/service.rs:4588`). This explains the visible fence without treating the generic scan-pending reason as a disk failure.

| Supported surface | Decision within A2/A3 |
| --- | --- |
| Inbox, issue, local status, native agents/readback | Observation only; used and target-filtered. |
| Normal service observation and retirement loop | Supported owner of native stop plus release/readback; initially pending, then observed to stop/release this execution and admit review. No second service or manual loop was started. |
| `service recover [--apply]` | Requires a hold; proposes/writes `gone` for a current attempt. It does not supply native release, and this result has already cleared the current attempt. Not applied. |
| Reviewed `service recover --request` | Owner/Stop recovery, with requeue effects and platform constraints; outside this scope. Not applied. |
| `service app-server ... reconcile`, `service slots ... release` | Different external-consumer protocols and identities; not a Claude task-execution reconciliation interface. Not applied. |
| Native stop, PID termination, hand-written release, requeue/review rerun, restart/reboot | No supported, scoped TaskQ reconciliation proved here. No such action was taken. |

**Manual interface gap:** the current CLI catalog provides no single-execution TaskQ command that addresses this existing task/attempt/execution and original native job and completes retirement without requeue or input. While the original process was live, native turn completion could not replace its process-exit proof. No manual reconciliation was applied. The existing service subsequently completed that supported identity-bound retirement, wrote the exact release and admitted review only afterward; no new manual boundary is now needed to unblock this execution (R2, R9, R11, R12; section 3).

## Comparison with agentq 263

The immutable sanitized evidence attached to [agentq 263](https://github.com/taskqorg/agentq/issues/263) records a different execution: Codex reviewer 6680810578 for agentq task 260. Its log lines 41-43 show a `codex-main` Rust panic: `failed printing to stdout: There is not enough space on the disk. (os error 112)`. Its board records exit 101. A subsequent rollout-channel-closed error follows that panic.

For execution 6680828219, the observed runtime is Claude; initially its original process was live with a terminal turn, then it was stopped and released normally. No equivalent stdout panic or os-error-112 failure was found in the target attempt log's tool-result failures. The native job timeline did mention `host disk at 100%` while working. This is storage-pressure context, not proof that error 112 caused TaskQ's history scan to remain pending. The other report does not establish the affected volume/storage layer. **Causal relationship: unknown.** Reject transferring the Codex exit-101 diagnosis to this Claude execution without direct evidence (R12). Current free space does not prove historical free space.

The comparison ZIP was freshly downloaded from its immutable published URL, SHA-256 `27ed7232f84d922f7404d7aaa28b53d38a8c5ab15a7b7fb7e2cf0c7217a1d4e2`. No other agentq native session or local log was read. Fresh inbox note 6681722159 says the owner ended the storage investigation after Windows cleanup and limits this task to the original execution fence. The relationship remains unknown; no further disk-space or stdout-sink collection will be performed. The later release is not proof of a storage cause.

## Preservation and verification

The result SHA and result comment remain unchanged. This investigation changed no source, original archive, native input, process, grant, host policy or queue state of task 2463. The service's separate automatic stop/release and subsequent reviewer admission are recorded above. Task 2482's owned worktree remains clean at `fcd59963daad8686abba192df1557224ed2b0e9c`.

Fresh downloads from the exact result's existing immutable URLs matched both recorded hashes; neither archive was regenerated or substituted:

| Archive | Bytes | SHA-256 |
| --- | ---: | --- |
| Retained evidence | 35872 | `38bbe17dd0d12b64b454942e1c7e970b27bff466e96007494fd6e0806515af1d` |
| Retained canonical source | 8555500 | `c3b6b60d64b9509428bef32d60d28100c8ab10aba458906a621bdf32b2e1d045` |

The source commit remains readable as a Git commit. `observations.json` indexes `before-observations.json` and `after-observations.json`: artifact URLs/hashes, observed times, selected board entries, identity-bound process readback, native terminal summaries, local status, source hashes and explicit unknowns. Fresh archive downloads remain outside source Git and are not included in this small evidence package. The package includes only this report, sanitized observations and checksums. Before/after state change is observed; no code fix or regression-test pass is claimed. Builds and regression suites were not run for a read-only collection.

## Options

1. Accept the observed ordinary-service reconciliation and preserve its exact release receipt. Plus: no additional recovery action or source change is needed for this execution. Minus: the underlying prolonged scan remains undiagnosed below the exposed pending boundary.
2. Investigate persistent scan delays or a manual reconciliation interface under separately approved scope. Plus: could explain or improve recurrence handling. Minus: requires more instrumentation or implementation than this bounded read-only task permits; it is unnecessary to unblock the now-released execution.

## Verdict

**Confirmed:** reviewer admission was blocked by an unreleased, accepted execution whose original background process remained live while TaskQ's native observation was pending despite a completed native turn. The service subsequently stopped the exact native job, recorded release 6681722157 and admitted reviewer 6681723539, preserving the original result. **Inconclusive:** the underlying prolonged scan and any causal connection to agentq 263's stdout storage panic. A1-A4 evidence collection is complete. No manual reconciliation was applied.

## Recommendation

Preserve result 6681009909, SHA ee39a45, both original archives and release receipt 6681722157. No further recovery is needed for execution 6680828219. Let the already-admitted reviewer continue under its own attempt; this investigation does not inspect or direct it. Do not synthesize releases from results, turn-duration records, heartbeats, idle status or elapsed time. This diagnosis does not depend on task 2463 completing.

## Completion constraint

Task 2482 is labeled `research`. Section 7 and `docs/design/reports.md` require `docs/research/2482.md` in its result candidate. A3 forbids source edits, and A4 requires evidence outside source Git. The clean baseline has no such report. `src/cli/handin.rs:76` calls `reports::prepare` before a result is written; `src/reports.rs:1423` requires the tracked report when the research label is present. An outside-Git attachment cannot satisfy that current gate.

Fresh inbox note 6681482099 identifies this as a PM classification defect and settles preservation: do not create a tracked report, rerun collection or weaken scope. It confirms the installed CLI lacks a revision-bound type/completion-route amendment. This is a separate completion gate, not an unresolved choice about the accepted no-source-edit scope and not an execution-fence blocker for task 2463. An audited completion-route reconciliation preserving the task/attempt, no-edit scope and exact evidence identity is missing. This report is attached evidence, not an accepted source result. No result or rule assertion was bypassed and no label was changed (R5, R12, R13; section 7).

## Proposed tasks

No task was filed or started. Additional scan instrumentation is optional future PM triage, not an authorized implementation or a dependency of this collection. No recovery task is proposed for this now-released execution.

```taskq-tasks
[]
```
