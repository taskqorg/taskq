# Antigravity native exact-input proof on Windows

Candidate ee39a45cdaf50f9ebc9d4de3c9a8fc92118b2e34; task #2463, same attempt 6675965760. This addendum closes the evidence gap identified by reviewer requeue 6675943767. No source change or new native turn was needed.

## Observation and provenance

The accepted owner answer 6677791656 to question 6676033348 authorizes this read-only audit of the one owned native conversation. PM steer 6677824747 preserves that scope. The native per-conversation SQLite DB has cascade_id 54730d96-06f6-47ce-80c5-62e817f1e359, matching the retained native start/resume stream and launch receipts. No credentials, other conversations or shared history database were read.

The original DB has no WAL/journal. A byte-for-byte OS-temp copy passed SQLite quick_check and was opened read-only with immutable=1. Both original bytes and mtime remained unchanged throughout the audit. See proof.json for original DB, each step payload, native stream, candidate artifact and prior evidence hashes. The raw DB and full payloads remain private because they contain runtime context.

Both full 293-byte inputs are present as complete native length-delimited protobuf fields, with byte-for-byte equality to the expected inputs: step 0 is start and step 2 is resume. Each matches independently at field paths 19/2 and 19/3/1. The extracted native text, original selected field envelope, offsets, field lengths and SHA-256 values are attached. This is whole-field equality, not substring or canary-only proof. The parser decodes protobuf wire framing without asserting a vendor schema; its assertions reject truncated fields and malformed varints.

The DB user steps have type 14/status 3 and their serialized type/status agree. The native stream independently identifies the same step indexes as user_input/DONE in the same conversation. The corresponding successful responses are also present in native DB steps 1 and 4, matching the retained stream's distinct canary responses and completion receipts. The stream result adds a terminal LF absent from the native response fields; response comparison removes that LF only. Input comparisons do not trim or normalize anything. Both full inputs are now independently observed after native receipt, rather than inferred from TaskQ producer serialization.

## Candidate and acceptance boundaries

A1: the formerly unknown Antigravity full native start/resume input is now proved. The eight historical native turns and transcript parity receipts remain retained. Those turns originally ran on 12699ff8eed7d16ac721090654e802648ccc0c63; only src/service.rs and src/service_tests.rs differ in the corrected candidate, so the runtime/input implementation, dependencies and original client versions are unchanged. This reuse follows the accepted PM reconciliation and SpecQ Testing run policy. It is not a claim that those historical turns were newly dispatched on ee39a45.

A2: the corrected candidate's separate native-client Service qualification remains 52/52 equal startup/running/terminal status/heartbeat pairs, excluding only observation times and process_id. The nested previous-corrected-evidence.zip includes original receipts, exact source/artifact identity, before-failure/after-pass evidence, canonical gate and fixture boundaries. Its older Antigravity unknown statements are historical and superseded only by this addendum.

A3: no model turn, runtime start/resume, input replay, grant, login, model, effort, capacity or service mutation occurred during this audit. Earlier per-launch authority, completion and unrelated-session preservation receipts retain their original historical scope. This audit's only native record access was the accepted owned conversation read.

A4: the sanitized archive remains outside Git. The assigned worktree is unchanged. Exclusive source ownership remains #2427. No rebase, push, PR, install or production service change occurred in this continuation.

Installed candidate service, real-board transport, containment, telemetry and merge_group CI remain unqualified. The in-process Service uses a fixture board with native clients; these boundaries are not waived. This addendum supplies the missing A1 input evidence, not production rollout or unrestricted Windows qualification.

Applied R2: same attempt, no second writer or executor. R5: sanitized evidence through result --file. R9: accepted read scope only; no runtime permission grant or launch. R12: exact native input proof and immutable candidate/artifact hashes, with historical reuse and unqualified boundaries explicit. No rules amended. No new fix was made; the retained startup correction's before/after evidence remains in the previous archive.
