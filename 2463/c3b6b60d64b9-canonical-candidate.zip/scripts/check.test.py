"""R12: doc-only selection cannot hide Rust/config/unknown or missing impact."""
from pathlib import Path
import runpy

check = runpy.run_path(str(Path(__file__).with_name('check.py')))
select, names = check['selection'], check['runtime_names']
for paths, expected in [([], 'full'), (['README.md'], 'docs'), (['AGENTS.md'], 'full'),
                        (['taskq.md'], 'full'), (['docs/design/product-contract.md'], 'full'),
                        (['docs/design/product-contract.md', 'README.md'], 'full'), (['docs/design/answer-card.md'], 'web'),
                        (['src/tray.html', 'tests/tray-action.test.cjs'], 'web'),
                        (['src/core.rs', 'README.md'], 'full'), (['Cargo.lock'], 'full'),
                        (['tests/fixtures/status-snapshot.json'], 'full'),
                        (['.github/workflows/tests.yml'], 'full'), (['unknown'], 'full')]:
    assert select(paths) == expected, (paths, select(paths), expected)
print('PASS change selection; unknown impact broadens')

# Owner-operation fixtures must not inherit a live worker identity or board credential; the launching session stays bound.
import json
import os
import subprocess
import sys
import tempfile
with tempfile.TemporaryDirectory(prefix='taskq-check-context-') as install:
    parent = {**os.environ, 'TASKQ_TASK': '1840', 'TASKQ_ATTEMPT': 'invented-attempt', 'TASKQ_ROLE': 'worker',
              'TASKQ_ROOT': 'invented-project', 'TASKQ_INSTALL': 'invented-production-install', 'CODEX_THREAD_ID': 'invented-thread', 'GH_TOKEN': 'invented-token', 'CARGO_BUILD_JOBS': '2', 'TASKQ_INCIDENT_REPORTS': 'off'}
    child = check['test_environment'](check['check_environment'](parent), install)
    observed = json.loads(subprocess.check_output([sys.executable, '-c',
        'import os,json;print(json.dumps({k:os.environ.get(k) for k in ["TASKQ_TASK","TASKQ_ATTEMPT","TASKQ_ROLE","TASKQ_ROOT","CODEX_THREAD_ID","GH_TOKEN","TASKQ_INSTALL","CARGO_BUILD_JOBS","TASKQ_INCIDENT_REPORTS"]}))'], env=child))
    assert observed == {'TASKQ_TASK': None, 'TASKQ_ATTEMPT': None, 'TASKQ_ROLE': None, 'TASKQ_ROOT': None, 'CODEX_THREAD_ID': None,
                        'GH_TOKEN': None, 'TASKQ_INSTALL': install, 'CARGO_BUILD_JOBS': '2', 'TASKQ_INCIDENT_REPORTS': None}
    assert parent['TASKQ_TASK'] == '1840' and parent['GH_TOKEN'] == 'invented-token' and parent['TASKQ_INSTALL'] == 'invented-production-install'
print('PASS isolated fixture installation, worker identity and credentials; launching context preserved')

# #1940: reduce process oversubscription, retaining all fixture deadlines and explicit CI overrides.
env = {k:v for k,v in os.environ.items() if k != 'RUST_TEST_THREADS'}
shaped = check['test_environment'](env, 'invented-install')
if sys.platform == 'win32':
    assert shaped['RUST_TEST_THREADS'] == str(min(4, os.cpu_count() or 1))
assert check['test_environment']({**env, 'RUST_TEST_THREADS':'2'}, 'invented-install')['RUST_TEST_THREADS'] == '2'
print('PASS bounded Windows harness concurrency; explicit override preserved')

assert names('src/tray.rs', 'if rt == "claude" {}') == ['src/tray.rs:1: if rt == "claude" {}']
assert names('src/tray.rs', 'of(rt).remote\n#[cfg(test)]\nmod tests {\nlet rt = "codex";\n}') == []
# Code after a test-only item or test module is still scanned.
assert names('src/x.rs', '#[cfg(test)]\nfn f() {}\nlet a = "codex";') == ['src/x.rs:3: let a = "codex";']
assert names('src/x.rs', '#[cfg(test)]\nmod t {\n    fn f() { "claude"; }\n}\nlet a = "codex";') == ['src/x.rs:5: let a = "codex";']
assert names('src/x.rs', '#[cfg(test)]\npub(crate) mod tests {\n"codex";\n}') == []
# Name-prefixed literals count.
assert names('src/x.rs', 's.starts_with("claude:")') == ['src/x.rs:1: s.starts_with("claude:")']
assert names('src/runtime/table.rs', 'const C: &str = ".claude.json";') == []
# #2271: names are table data, never a branch, and the table is no exception to that; capability lookups pass.
for path in ['src/runtime/table.rs', 'src/runtime.rs', 'src/runtime/owner.rs', 'src/linux_sandbox.rs']:
    for planted in ['if rt == "codex-app" {}', 'if "claude" == rt {}', '"antigravity" => x,', 'matches!(rt, "claude" | "codex")', 'binding["runtime"]!="codex"']:
        assert names(path, planted) == [f'{path}:1: {planted}'], (path, planted)
assert names('src/runtime/table.rs', 'Adapter { name: RUNTIMES[1], bin: "codex" }\nwhich("claude")') == []
# #2427: only the table holds names; no sandbox file or runtime module is exempt.
for path in ['src/runtime.rs', 'src/runtime/owner.rs', 'src/windows_sandbox.rs', 'src/windows_sandbox/acl.rs', 'src/linux_sandbox.rs']:
    for planted in ['which("claude")', 'bin: "codex"', 'tasklist claude.exe', 'env("CODEX_HOME", h)']:
        assert names(path, planted) == [f'{path}:1: {planted}'], (path, planted)
    assert names(path, 'if of(rt).has(Cap::ThreadLink) {}') == [], path
# #1593: a planted bypass in main.rs or a former exception fails, native names included
for planted in ['if k.runtime=="claude" {}', 'if k.runtime=="antigravity" {}', 'tasklist claude.exe', 'home.join(".claude.json")', 'env("CODEX_HOME", h)', 'env_remove("CODEX_THREAD_ID")']:
    for path in ['src/main.rs', 'src/labels.rs', 'src/host.rs', 'src/setup.rs']:
        assert names(path, planted) == [f'{path}:1: {planted}'], (path, planted)
print('PASS runtime names stay in the adapter')

# Rule-change gate (docs/design/rule-ids.md#contract-detail). Defect: bf4a2be9 (#1776) rewrote the M3 host strip
# rule and its tests, ecb1e57d dropped `Take requests`, both unnamed by their tasks; review missed both.
# Risk kept: a rule or rule-citing test changes or disappears unless the task names its ID.
blocks, findings, unnamed, uncovered = check['rule_blocks'], check['rule_findings'], check['unnamed'], check['uncovered']
root = Path(__file__).resolve().parents[1]
head = {p: (root / p).read_text(encoding='utf-8') for p in check['RULE_DOCS']}
ids = check['doc_rules'](head)
assert {'R1', 'R13', '§1', '§9', '§2 Ask card', 'Change rule', '§2.1', '§2.25', 'M3', 'M3.25'} <= ids.keys(), sorted(ids)
assert 'host strip' in ids['M3.1'] and '`hold`' in ids['§2.2'] and '`hold`' not in ids['§2'], ids['M3.1']
spec = '# t\npre\n## Principles (R1–R2)\n### R1. One\nalpha beta gamma.\n### R2. Two\nx\n## 2. Log\nlog text\n| a | b | ID |\n|---|---|---|\n| x | `y` | 1 |\n### Ask card (#9)\ncard text\n[l]: http://x\n'
doc = lambda text: {'taskq.md': text, 'docs/design/menu.md': ''}
assert blocks('taskq.md', spec) == {'Principles': '## Principles (R1–R2)', 'R1': '### R1. One alpha beta gamma.', 'R2': '### R2. Two x',
                                    '§2': '## 2. Log log text | a | b | ID | |---|---|---|', '§2.1': '| x | `y` | 1 |', '§2 Ask card': '### Ask card (#9) card text'}
assert blocks('docs/design/menu.md', '## M3 Nav\nintro\n- M3.2 two\n\nM3.1 one\nmore\n\nafter\n## Acceptance\nx\n') == \
    {'M3': '## M3 Nav intro after', 'M3.2': '- M3.2 two', 'M3.1': 'M3.1 one more'}
none = {'changed': [], 'removed': [], 'tests': []}
# A typo fix passes unnamed; a meaning word, a number, code or a third word does not.
assert findings(doc(spec), doc(spec.replace('gamma.', 'gama.')), '') == none
for edit in [('beta', 'not'), ('pre', 'changed preamble'), ('x |', 'z |'), ('beta gamma', 'beta gamma delta'), ('Two\nx', 'Two\n2')]:
    expected = {'beta': ['R1'], 'pre': [], 'x |': ['§2.1'], 'beta gamma': ['R1'], 'Two\nx': ['R2']}[edit[0]]
    assert findings(doc(spec), doc(spec.replace(*edit, 1)), '')['changed'] == expected, edit
assert findings(doc(spec), doc(spec.replace('alpha beta', 'alpha deta').replace('gamma', 'gama').replace('One', 'Onn')), '')['changed'] == ['R1']
# Removals need a destination; `§2 Ask card` does not name `§2`, `§ 2` does not name `§2.1`.
gone = findings(doc(spec), doc(spec.replace('### R2. Two\nx\n', '')), '')
assert gone == {'changed': [], 'removed': ['R2'], 'tests': []}, gone
assert unnamed(gone, 'drops R2') == ['R2 (removed; name `R2 -> <ID, file or none>`)'] and unnamed(gone, 'R2 -> R1') == []
both = {'changed': ['§2', '§2.1', '§2 Ask card'], 'removed': [], 'tests': []}
assert unnamed(both, 'edits § 2 Ask card and §2.1') == ['§2 (changed)'] and unnamed(both, '§ 2, §2.1 and §2 Ask card') == []
# A changed or removed assertion or Chain: line citing an ID is listed; a moved one and an uncited one are not.
diff = '-    // Chain: § 2 x\n+    // Chain: § 2 y\n-assert!(a, "R1 b");\n+assert!(a, "R1 b");\n-assert!(c);\n-let s = "R2";\n'
assert findings(doc(spec), doc(spec), diff)['tests'] == ['§2'], findings(doc(spec), doc(spec), diff)
assert uncovered({'R1': '', '§2': '', '§2.1': ''}, '// Chain: § 2 table, R1') == ['§2.1']
print('PASS rule IDs, typo fixes and the gate on synthetic contracts')

# Chain: Product, #2377 compaction moved Product text to its detail page -> gate and lane. Defect: the page sat outside
# RULE_DOCS, so an edit there listed no ID while the same edit in the root listed Product, and it ran the docs lane.
# Risk kept: a decided Product rule changes or disappears, in either file, unless the task names Product.
product = check['PRODUCT_DOC']
assert product in check['RULE_DOCS']
assert 'twelve destinations' in ids['Product'] and 'product contract' in ids['Product'], ids['Product']
root_text, page = '## Product\nsee page\n## 1. Tasks\nt\n', '# P\n\n## Contract detail\n\n- twelve destinations\n'
split = lambda r, p: {'taskq.md': r, 'docs/design/menu.md': '', product: p}
assert check['doc_rules'](split(root_text, page))['Product'] == '## Product see page # P ## Contract detail - twelve destinations'
listed = {'changed': ['Product'], 'removed': [], 'tests': []}
for before, after in [(split(root_text, page), split(root_text, page.replace('twelve', 'nine'))),  # page edit
                      (split(root_text, page), split(root_text.replace('see page', 'see other'), page)),  # root edit
                      (split(root_text, page), split(root_text, '')),  # page deleted
                      (split(root_text, page), split(root_text, page + '## Later\n\n- new rule\n')),  # new heading stays Product
                      (split('## Product\n- twelve destinations\n', ''), split(root_text, page))]:  # the move itself
    assert findings(before, after, '') == listed, after
    assert unnamed(listed, 'Fix a typo.') == ['Product (changed)'] and unnamed(listed, 'edits Product') == []
assert findings(split(root_text, page), split(root_text, page), '') == none
print('PASS Product detail page stays under the rule gate and full lane')

# #1826 R13: the owner named "section 7" and its exact subsection. Preserve ID boundaries and require both;
# accepting the ordinary spelling must not approve another section, table row or unnamed change.
report_rules = {'changed': ['§7', '§7 Result and close verdicts'], 'removed': [], 'tests': ['§7']}
assert unnamed(report_rules, 'amend section 7 and section 7 Result and close verdicts') == []
assert unnamed(report_rules, 'amend section 7 Result and close verdicts') == ['§7 (changed)', '§7 (tests)']
assert unnamed(report_rules, 'amend section 70') == ['§7 (changed)', '§7 Result and close verdicts (changed)', '§7 (tests)']

# Replays against their parents; the CI plan job checks out full history.
for rev, listed in [('bf4a2be9', {'changed': ['M3'], 'tests': ['R12']}), ('ecb1e57d', {'removed': ['§7 Take requests'], 'changed': ['R1', '§7']})]:
    found = findings(check['git_docs'](rev + '^'), check['git_docs'](rev), check['test_diff'](rev + '^', rev))
    assert all(set(v) <= set(found[k]) for k, v in listed.items()), (rev, found)
    assert unnamed(found, 'Fix a typo.'), rev
    task = ' '.join(found['changed'] + found['tests'] + [f'{k} -> none' for k in found['removed']])
    assert unnamed(found, task) == [], (rev, unnamed(found, task))
# #2118: preserve plural section citations without approving unnamed sections, rows or subsections.
plural = {'changed': ['§4', '§9', '§3', '§4.1', '§4 Profiling'], 'removed': [], 'tests': []}
assert unnamed(plural, 'sections 4 Filter and 9') == ['§3 (changed)', '§4.1 (changed)', '§4 Profiling (changed)']
assert unnamed(plural, 'sections 4 and 90') == ['§9 (changed)', '§3 (changed)', '§4.1 (changed)', '§4 Profiling (changed)']
assert unnamed(plural, 'sections 4 Profiling and 9') == ['§4 (changed)', '§3 (changed)', '§4.1 (changed)']
# #2136: compact owner citations keep section and subsection boundaries.
assert unnamed(plural, 'R13/sections4/9') == ['§3 (changed)', '§4.1 (changed)', '§4 Profiling (changed)']
assert unnamed({'changed': ['§8', '§80', '§8 Access'], 'removed': [], 'tests': []}, 'amend section8') == ['§80 (changed)', '§8 Access (changed)']
assert unnamed(plural, 'sections4/90') == ['§9 (changed)', '§3 (changed)', '§4.1 (changed)', '§4 Profiling (changed)']
print('PASS replays of bf4a2be9 and ecb1e57d fail unnamed and pass named')

# Chain: §1 Task text, #2241 declared rule scope -> gate. Risk: an in-scope edit still asks, or the scope approves
# an ID outside it (a sibling section, a longer number) or a removal without its destination.
scoped = {'changed': ['§2', '§2.20', '§2 Ask card', '§20', 'R7'], 'removed': ['§2.3'], 'tests': ['§2.9']}
removal = '§2.3 (removed; name `§2.3 -> <ID, file or none>`)'
assert unnamed(scoped, '', 'Goal: x\nRules: §2') == ['§20 (changed)', 'R7 (changed)', removal]
assert unnamed(scoped, '', 'Rules: section 2, R7') == ['§20 (changed)', removal]
assert unnamed(scoped, '§2.3 -> none', 'Rules: all') == []
assert unnamed(scoped, '', 'Rules: R70') == [f'{k} (changed)' for k in scoped['changed']] + ['§2.9 (tests)', removal]
# a `Rules:` line quoted in ask context or an answer is task text, not a declared scope
assert unnamed(scoped, 'Rules: all\n§2.3 -> none', '') == [f'{k} (changed)' for k in scoped['changed']] + ['§2.9 (tests)']
assert unnamed(scoped, '§2.3 -> none', ' Rules: all\nRules: contract') == [f'{k} (changed)' for k in scoped['changed']] + ['§2.9 (tests)']
print('PASS declared rule scope passes inside, asks outside')


# #1818 / #1805: the owner picked the design, but Product appeared only in the ask's context.
# Keep the real task_text -> approval gate boundary; the subprocesses return invented board data.
import json
from types import SimpleNamespace
subprocess = check['task_text'].__globals__['subprocess']
old_run, old_output = subprocess.run, subprocess.check_output
ask = {'id': 10, 'body': 'taskq: ask attempt 1\nProblem: Approval updates Product and M2.\n1. A; native at release - + compact; - later qualification\n2. B - + wider; - changes R9',
       'author_association': 'OWNER', 'created_at': 'invented', 'updated_at': 'invented'}
answer = {**ask, 'id': 11, 'body': 'taskq: answer 1\nA; native at release - + compact; - later qualification'}
try:
    subprocess.check_output = lambda *a, **k: b'Task: https://github.com/invented/project/issues/1\n'
    def board_read(command, **kwargs):
        if command[-1].endswith('/comments'):
            out = json.dumps([[{**ask, 'id': 1, 'body': 'taskq: spawn worker codex:invented win'}, ask, answer]]) if '--slurp' in command else answer['body']
        else:
            out = 'Design A is approved by the owner.'
        return SimpleNamespace(returncode=0, stdout=out.encode(), stderr=b'')
    subprocess.run = board_read
    approved, _, error = check['task_text']('invented-base')
    assert error is None, error
    assert unnamed({'changed': ['Product', 'M2'], 'removed': [], 'tests': []}, approved) == [], approved
    assert 'R9' not in approved, 'the unchosen option is not approval'
finally:
    subprocess.run, subprocess.check_output = old_run, old_output
print('PASS selected design approval reads its ask without asking the owner again')

# Pair approvals with the accepted question, never stale revisions, ignored asks or other options.
approval = lambda comments: check['approval_text'](comments, 99)
comment = lambda i, body, **fields: {**ask, 'id': i, 'body': body, **fields}
spawn = comment(1, 'taskq: spawn worker codex:invented win')
steer = comment(2, 'taskq: steer\nOwner approves R6 status block\nop-id: owner-steer\nrevision: 1')
assert 'R6' in approval([spawn, steer]), 'accepted owner steering is binding task text, without another answer'
held_review=[comment(1,'taskq: hold'),comment(2,'taskq: steer\nR9 intake only\nop-id: intake\nrevision: 1'),
             comment(3,'taskq: start\nop-id: start\nrevision: 2'),comment(4,'taskq: spawn worker codex:invented win'),
             comment(5,'taskq: ask attempt 4\nProblem: Amend Product and M3.\n1. Approve\n2. Keep'),comment(6,'taskq: answer 1')]
held_approval=approval(held_review)
assert 'Product' in held_approval and 'M3' in held_approval,'#2343: accepted held notes advance the revision before start and the named ask'
assert 'R9' not in held_approval,'held intake updates revision without granting rule approval'
for history in [[steer], [spawn, {**steer, 'updated_at': 'edited'}], [spawn, {**steer, 'author_association': 'NONE'}],
                [spawn, comment(2, 'taskq: steer attempt 1\nR6')],
                [spawn, comment(2, 'taskq: steer\nR6\nop-id: stale\nrevision: 0')],
                [spawn, ask, comment(12, 'taskq: steer\nR6')],
                [spawn, comment(2, 'taskq: result ' + 'a'*40 + ' attempt 1'), comment(3, 'taskq: steer\nR6')],
                [spawn, comment(2, 'taskq: gone attempt 1'), comment(3, 'taskq: steer\nR6')]]:
    assert 'R6' not in approval(history), 'steering keeps state, trust, revision and attempt fences'
assert 'R9' not in approval([spawn, steer, comment(3, 'taskq: steer\nR9\nop-id: owner-steer\nrevision: 1')]), 'a duplicate operation cannot add approval'
for answer_body in ['taskq: answer 1', '1', '1. A; native at release - + compact; - later qualification',
                    'taskq: answer\nPick 1. Proceed.', 'taskq answer 1', 'taskq answer 99.1', 'taskq answer #99.1',
                    'taskq: answer\n99.1', 'taskq: answer\n#99.1']:
    text = approval([spawn, ask, comment(11, answer_body)])
    assert 'Product' in text and 'M2' in text and 'R9' not in text, (answer_body, text)
# #2194: an `N.K` answer text of another task picks nothing
for answer_body in ['taskq: answer\n98.1', 'taskq: answer\n#98.1']:
    assert 'Product' not in approval([spawn, ask, comment(11, answer_body)]), answer_body
for rejected in [comment(11, 'taskq: answer 1\nR12\nop-id: stale\nrevision: 9'),
                 comment(11, 'taskq: answer 1 attempt 1'),
                 comment(11, '1', updated_at='edited'),
                 comment(11, '1', author_association='NONE')]:
    assert approval([spawn, ask, rejected]) == '', rejected
new_ask = comment(13, 'taskq: ask attempt 1\nProblem: New M3 choice\n1. keep\n2. change')
text = approval([spawn, ask, comment(11, 'taskq answer 2'), new_ask, comment(14, '1')])
assert 'M3' in text, text
replacement = [spawn, comment(2, 'taskq: requeue'), comment(3, 'taskq: spawn worker codex:new win'),
               comment(4, 'taskq: ask attempt 1\nProblem: Ignored R9\n1. old\n2. other'),
               comment(5, 'taskq: ask attempt 3\nProblem: Current M2\n1. keep\n2. change'), comment(6, '1')]
text = approval(replacement)
assert 'M2' in text and 'R9' not in text, text
for prefix in [
    [spawn, comment(2, 'taskq: spawn worker codex:ignored win')],
    [spawn, comment(2, 'taskq: result invalid attempt 1')],
    [comment(1, 'taskq: hold'), comment(2, 'taskq: requeue')],
    [spawn, comment(2, 'taskq: result ' + 'a'*40 + ' attempt 1'), comment(3, 'taskq: close'),
     comment(4, 'taskq: later'), comment(5, 'taskq: requeue')],
    [spawn, comment(2, 'taskq: requeue attempt 1')],
]:
    invalid = prefix + [comment(7, 'taskq: spawn reviewer codex:ignored win'),
                        comment(8, 'taskq: ask attempt 7\nProblem: Ignored R9\n1. yes\n2. no'), comment(9, '1')]
    assert 'R9' not in approval(invalid), invalid
replacement[1] = comment(2, 'taskq: requeue\nop-id: reset\nrevision: 1')
assert 'M2' in approval(replacement), 'a fenced reset must consume the old attempt'
assert approval([spawn, comment(2, 'taskq: requeue attempt 1'),
                 comment(3, 'taskq: ask attempt 1\nProblem: Ignored R9\n1. yes\n2. no'), comment(4, '1')]) == ''
assert approval([spawn, comment(2, 'taskq:  requeue\tattempt 1'),
                 comment(3, 'taskq: ask attempt 1\nProblem: Ignored R9\n1. yes\n2. no'), comment(4, '1')]) == ''
assert 'R9' not in approval([spawn, comment(2, 'taskq: ask attempt 1\nProblem: Choose\n1. keep\n1. change R9\n2. other'),
                            comment(3, 'taskq: answer 1')]), 'duplicate numbers retain the first option, as fold does'
assert 'R9' not in approval([spawn, comment(2, 'taskq: ask attempt 1\nProblem: Choose\n  1. keep\n  2. change R9'),
                            comment(3, 'taskq: answer 1')]), 'indented unchosen options are not ask context'
assert 'R9' not in approval([spawn, comment(2, 'taskq: ask attempt 1\nProblem: First\n1. keep\n2. other'),
                            comment(3, 'taskq: answer 1\nop-id: repeated id'),
                            comment(4, 'taskq: ask attempt 1\nProblem: New\n1. change R9\n2. keep'),
                            comment(5, 'taskq: answer 1\nop-id: repeated id')]), 'duplicate operations cannot approve a new ask'
# #1918: a reviewer requeue readied the task, but the gate dropped the next attempt's approved M8 ask.
def review_requeue(i, flag='', worker=None):
    return [comment(i, 'taskq: result ' + 'a'*40 + f' attempt {worker or i - 1}'), comment(i + 1, 'taskq: spawn reviewer claude:invented win'),
            comment(i + 2, f'taskq: requeue{flag} attempt {i + 1}'), comment(i + 3, 'taskq: spawn worker claude:invented win')]
approve_m8 = lambda i, rule='M8': [comment(i, f'taskq: ask attempt {i - 1}\nProblem: Approve {rule}\n1. approve {rule}\n2. keep R9'), comment(i + 1, '1')]
text = approval([spawn, *review_requeue(2), *approve_m8(6)])
assert 'M8' in text and 'R9' not in text, text
three = [spawn, *review_requeue(2), *review_requeue(6), *review_requeue(10)]
assert approval(three + approve_m8(14)) == '', 'the 3rd retry asks with the limit card, which fold models outside this gate'
three[7] = comment(8, 'taskq: requeue main-moved attempt 7')
assert 'M8' in approval(three + approve_m8(14)), 'main-moved keeps retries'
assert 'M8' in approval([spawn, *review_requeue(2), *approve_m8(6, 'M3'), *review_requeue(8, worker=5), *review_requeue(12), *approve_m8(16)]), \
    'an answer resets retries'
# #2159: a normal stage Later ends the attempt; an owner requeue admits a new approval lifecycle.
parked = [spawn, comment(2, 'taskq: later attempt 1'), comment(3, 'taskq: requeue'),
          comment(4, 'taskq: spawn worker codex:next win'),
          comment(5, 'taskq: ask attempt 4\nProblem: Retained Product document\n1. keep\n2. other'),
          comment(6, 'taskq: answer\nProduct retained reading approved\nop-id: resumed\nrevision: 5')]
assert 'Product retained reading approved' in approval(parked), 'stage Later must not discard a later owner decision'
for invalid in [parked[:2] + parked[3:],
                parked[:5] + [comment(6, 'taskq: answer\nProduct\nop-id: stale-stage\nrevision: 2')],
                parked[:5] + [comment(6, 'taskq: answer\nProduct', author_association='NONE')],
                parked[:5] + [comment(6, 'taskq: answer\nProduct', updated_at='edited')]]:
    assert approval(invalid) == '', 'stage parks retain admission, unsupported-transition, revision and trust fences'
# #2352: a worker `gone` (§2 row 10) made the gate unknown, so the replacement attempt's picked §4 and M8 ask never approved.
gone_ask = 'taskq: ask attempt 4\nDone: cuts\nProblem: Change §4 and M8.\n1. Change §4 - + less; - late\n2. Keep R9 - + none; - fails\nTo answer: `taskq answer 2352.K`.'
gone_steps = [comment(1, 'taskq: spawn worker claude:invented win'), comment(2, 'taskq: gone attempt 1'), comment(4, 'taskq: spawn worker claude:invented win')]
gone_text = lambda *rest: check['approval_text'](gone_steps + list(rest), 2352)
replaced = gone_text(comment(5, gone_ask), comment(6, 'taskq: released 4 exit attempt 4'), comment(7, 'taskq: answer 1\nChange §4 - + less; - late'))
assert '§4' in replaced and 'M8' in replaced and 'R9' not in replaced, replaced
assert '§4' not in gone_text(comment(5, gone_ask)), 'an unanswered ask grants nothing after gone'
assert '§4' not in gone_text(comment(5, gone_ask), comment(7, 'taskq: answer 1 attempt 4')), 'an attempt-bound answer grants nothing after gone'
assert 'M8' not in gone_text(comment(5, gone_ask), comment(7, 'taskq: answer 1\nop-id: stale\nrevision: 9')), 'a mismatched revision grants nothing after gone'
assert 'M8' not in gone_text(comment(5, gone_ask.replace('attempt 4', 'attempt 1')), comment(7, 'taskq: answer 1')), "the dead attempt's late ask grants nothing"
second_gone = [comment(5, 'taskq: gone attempt 4'), comment(6, 'taskq: spawn worker claude:invented win'), comment(7, gone_ask.replace('attempt 4', 'attempt 6')), comment(8, 'taskq: answer 1')]
assert gone_text(*second_gone) == '', 'the 2nd gone asks with the limit card: unmodelled, so the gate stays closed'
reviewer_gone = [comment(1, 'taskq: spawn worker claude:invented win'), comment(2, 'taskq: result ' + 'e'*40 + ' attempt 1'), comment(3, 'taskq: spawn reviewer claude:invented win'),
                 comment(4, 'taskq: gone attempt 3'), comment(5, 'taskq: spawn reviewer claude:invented win'), comment(6, gone_ask.replace('attempt 4', 'attempt 5')), comment(7, 'taskq: answer 1')]
assert check['approval_text'](reviewer_gone, 2352) == '', 'only a worker gone is modelled'
print('PASS rule gate: a picked ask after a worker gone approves; other grants stay closed')
# #2232: a worker `later <ref> attempt` park (§2 row 23) made the gate unknown, so #2210's later §8 pick never approved.
history_2210 = [comment(1, 'taskq: hold'), comment(2, 'taskq: start'), comment(3, 'taskq: spawn worker claude:invented win'),
                comment(4, 'taskq: accepted 3 attempt 3'), comment(5, 'taskq: later coreq#116 attempt 3\nReason: coreq orders pre-releases lexically'),
                comment(6, 'taskq: released 3 exit attempt 3'), comment(7, 'taskq: spawn worker claude:invented mac'),
                comment(8, 'taskq: spawn worker claude:ignored win'),
                comment(9, 'taskq: ask attempt 7\nDone: branch\nProblem: Tag coreq v0.19.1\nTo answer: `taskq answer 2210 --text <done>`.'),
                comment(10, 'taskq: requeue\nPM tagged coreq v0.19.1.'), comment(11, 'taskq: spawn worker claude:invented mac'),
                comment(12, 'taskq: result ' + 'd'*40 + ' attempt 11'), comment(13, 'taskq: spawn reviewer claude:invented win'),
                comment(14, 'taskq: ask attempt 13\nDone: reviewed PR\nProblem: §8 changed: dev builds X.Y.Z-yymmdd-N.\n'
                            '1. Approve §8 dev version format - + PR can merge; - none ★\n2. Keep §8 unchanged - + no change; - task unmet\n'
                            'To answer: `taskq answer 2210.K` or comment `K` or the option text.'),
                comment(15, 'taskq: answer 1\nApprove §8 dev version format - + PR can merge; - none'),
                comment(16, 'taskq: executing 15 attempt 13')]
replay = lambda history: check['approval_text'](history, 2210)
text = replay(history_2210)
assert '§8 changed' in text and 'Approve §8' in text and 'Keep §8' not in text, text
unbound = lambda body, **fields: replay(history_2210[:14] + [comment(15, body, **fields)])
for rejected in [unbound('taskq: answer 1 attempt 13'), unbound('taskq: answer 1\nop-id: stale\nrevision: 9'),
                 unbound('1', author_association='NONE'), unbound('1', updated_at='edited')]:
    assert '§8' not in rejected, rejected
assert '§8' not in replay(history_2210[:14]), 'an unanswered ask grants nothing after a park'
assert '§8' not in unbound('taskq: answer\nOwner approves'), 'an answer without a pick grants nothing'
assert 'Keep §8' not in replay(history_2210[:14] + [comment(15, '1')]) and 'Keep §8' in replay(history_2210[:14] + [comment(15, '2')])
assert '§8' not in replay(history_2210[:5] + [comment(7, 'taskq: ask attempt 3\nProblem: §8\n1. yes\n2. no'), comment(8, '1')]), \
    'the parked attempt cannot ask after the park'
# #2202: `taskq answer 2194 --text "2194.1 note"` resumed #2194, but the gate read no pick and stayed red.
section6 = comment(2, 'taskq: ask attempt 1\nProblem: A4 changes rule Shared project bootstrap.\n1. approve the edit\n2. drop the edit')
noted = lambda body: check['approval_text']([spawn, section6, comment(3, body)], 2194)
assert 'Shared project bootstrap' in noted('taskq: answer\n2194.1 Owner approves the section 6 edit'), 'a leading N.K pick with a note approves'
assert 'Shared project bootstrap' in noted('taskq: answer\n#2194.1'), 'a bare N.K pick approves'
for unpicked in ['taskq: answer\nOwner approves the section 6 edit', 'taskq: answer\n2193.1 Owner approves', 'taskq: answer\n2194.1x']:
    assert 'Shared project bootstrap' not in noted(unpicked), unpicked
print('PASS approval association preserves revision, attempt, trust and selected-option fences')

# #2210: dev builds are <next patch>-yymmdd-N; N counts the UTC date's builds on the host and restarts each day.
import datetime
dev = runpy.run_path(str(Path(__file__).with_name('dev-version.py')))['version']
cargo, utc = 'version = "4.6.59"\n', datetime.timezone.utc
day1, day2 = datetime.datetime(2026, 11, 2, 23, 59, tzinfo=utc), datetime.datetime(2026, 11, 3, 0, 0, tzinfo=utc)
assert dev(cargo, ['4.6.60-dev.1793639858'], day1) == '4.6.60-261102-0'
assert dev(cargo, ['4.6.60-dev.1793639858', '4.6.60-261102-0'], day1) == '4.6.60-261102-1'
assert dev(cargo, [f'4.6.60-261102-{n}' for n in range(11)], day1) == '4.6.60-261102-11'
assert dev(cargo, ['4.6.60-261102-0', '4.6.60-261102-1'], day2) == '4.6.60-261103-0'
assert dev(cargo, ['4.6.59-261102-4'], day1.astimezone(datetime.timezone(datetime.timedelta(hours=3)))) == '4.6.60-261102-5'
# #2234: releases take their version from the tag, so a dev build follows the highest release tag above Cargo.toml.
assert dev(cargo, [], day1, ['v4.6.59', 'v4.6.70', 'v4.6.9', 'v5.0.0-rc1', 'vx']) == '4.6.71-261102-0'
assert dev('version = "4.7.0"\n', [], day1, ['v4.6.70']) == '4.7.1-261102-0'
print('PASS dev version counts per UTC day and follows the release tags')
release_index = runpy.run_path(str(Path(__file__).parents[1] / '.github' / 'release-index.py'))['index']
fast, latest = release_index('4.7.1', '', {'taskq-4.7.1-linux-x86_64': 'aa', 'taskq-4.7.1-windows-x86_64.exe': 'bb', 'other': 'cc'})
assert fast == 'aa  taskq-4.7.1-linux-x86_64\nbb  taskq-4.7.1-windows-x86_64.exe\n'
assert latest == {'version': '4.7.1', 'files': {'linux-x86_64': 'taskq-4.7.1-linux-x86_64', 'windows-x86_64': 'taskq-4.7.1-windows-x86_64.exe'}}
full, latest = release_index('4.7.1', fast, {'taskq-4.7.1-macos-aarch64': 'dd', 'taskq-4.7.1-linux-x86_64': 'aa'})
assert full == 'aa  taskq-4.7.1-linux-x86_64\ndd  taskq-4.7.1-macos-aarch64\nbb  taskq-4.7.1-windows-x86_64.exe\n', 'macos joins the published sums'
assert sorted(latest['files']) == ['linux-x86_64', 'macos-aarch64', 'windows-x86_64']
print('PASS release index publishes OS files as they arrive')

# #2236: the contract lint's above-target markers stay visible locally and as CI annotations.
warn = check['compact_warnings']
report = 'taskq.md: 60024 bytes\nCOMPACT: taskq.md: 60024 bytes > target 55910 (cap 79872)\nPASS\n'
assert warn(report) == ['Warning: COMPACT: taskq.md: 60024 bytes > target 55910 (cap 79872); file one compaction task (specq engineering/contracts.md#size-budgets)']
assert warn(report, True)[0].startswith('::warning::COMPACT: taskq.md: 60024 bytes')
assert warn('taskq.md: 55898 bytes\nPASS\n') == []
print('PASS contract lint COMPACT markers surface as warnings')

# R8/R12: unavailable contract lint must refuse before any test/build command.
from unittest.mock import patch
import hashlib
import io
gate = check['main'].__globals__
with tempfile.TemporaryDirectory(prefix='taskq-lint-unavailable-') as directory:
    lint = check['contract_lint']
    with patch.dict(gate, changes=lambda _: ['README.md'], rule_gate=lambda _: None,
                    contract_lint=lambda: lint(Path(directory))), \
         patch.object(sys, 'argv', ['check.py']), \
         patch.dict(os.environ, {}, clear=True), \
         patch('urllib.request.urlopen', side_effect=OSError('offline')) as download, \
         patch.object(subprocess, 'run', side_effect=AssertionError('checks started before contract lint')):
        try:
            check['main']()
        except SystemExit as error:
            assert 'contract lint unknown (R12)' in str(error), error
        else:
            raise AssertionError('unavailable lint passed')
        assert download.call_count == 1, 'no preparation retries'
print('PASS unavailable contract lint refuses before checks')

# R8: fetch only the pinned standalone script, verify before publishing/executing,
# reuse valid caches offline and refuse invalid checkout/cache/download bytes.
body = b'print("fixture lint")\n'
with tempfile.TemporaryDirectory(prefix='taskq-lint-cache-') as directory, \
     patch.dict(gate, CONTRACT_LINT_SHA256=hashlib.sha256(body).hexdigest()):
    root = Path(directory)
    cached = root / '.taskq' / 'specq' / check['SPECQ'] / check['CONTRACT_LINT']
    with patch('urllib.request.urlopen', return_value=io.BytesIO(body)) as download:
        command = lint(root)
        assert command == [sys.executable, str(cached), 'taskq.md']
        download.assert_called_once_with(
            f'https://raw.githubusercontent.com/taskqorg/specq/{check["SPECQ"]}/engineering/scripts/contract_lint.py', timeout=10)
    assert cached.read_bytes() == body
    with patch('urllib.request.urlopen', side_effect=AssertionError('offline cache fetched')):
        assert lint(root) == command
    checkout = root / '.specq' / check['CONTRACT_LINT']
    checkout.parent.mkdir(parents=True)
    checkout.write_bytes(body)
    with patch('urllib.request.urlopen', side_effect=AssertionError('CI checkout fetched')):
        assert lint(root)[1] == str(checkout)
    for invalid in (checkout, cached):
        invalid.write_bytes(b'changed')
        with patch('urllib.request.urlopen', side_effect=AssertionError('invalid local copy fetched')):
            try:
                lint(root)
            except SystemExit as error:
                assert 'unknown (R12)' in str(error) and 'SHA-256 mismatch' in str(error), error
            else:
                raise AssertionError('invalid local linter accepted')
        invalid.unlink()
    for invalid in (b'changed', b'x' * (128 * 1024 + 2)):
        with patch('urllib.request.urlopen', return_value=io.BytesIO(invalid)):
            try:
                lint(root)
            except SystemExit as error:
                assert 'SHA-256 mismatch' in str(error), error
            else:
                raise AssertionError('invalid downloaded linter accepted')
        assert not cached.exists(), 'unverified bytes never published'
print('PASS pinned lint preparation, offline reuse and integrity refusal')

# R8/R12: a linked worktree reuses the main checkout's verified linter read-only; an invalid copy refuses, and only its absence downloads.
git = lambda cwd, *args: subprocess.run(['git', '-C', str(cwd), '-c', 'user.name=t', '-c', 'user.email=t@invalid', '-c', 'commit.gpgsign=false', *args], check=True, capture_output=True,
                                        env={k: v for k, v in os.environ.items() if not k.startswith('GIT_')})
def refusal(root):
    try:
        lint(root)
    except SystemExit as error:
        return str(error)
    raise AssertionError('invalid or unavailable linter accepted')
with tempfile.TemporaryDirectory(prefix='taskq-lint-worktree-') as directory, \
     patch.dict(gate, CONTRACT_LINT_SHA256=hashlib.sha256(body).hexdigest()):
    main = Path(directory).resolve() / 'main'
    main.mkdir()
    git(main, 'init', '-q')
    git(main, 'commit', '-q', '--no-verify', '--allow-empty', '-m', 'fixture')
    linked = main / '.worktrees' / 'taskq-1'
    git(main, 'worktree', 'add', '-q', '--detach', str(linked))
    assert check['main_checkout'](linked) == main and check['main_checkout'](main) is None
    shared = main / '.taskq' / 'specq' / check['SPECQ'] / check['CONTRACT_LINT']
    own = linked / '.taskq' / 'specq' / check['SPECQ'] / check['CONTRACT_LINT']
    shared.parent.mkdir(parents=True)
    shared.write_bytes(body)
    with patch('urllib.request.urlopen', side_effect=AssertionError('valid main checkout copy downloaded')):
        assert lint(linked)[1] == str(shared)
    assert shared.read_bytes() == body and not (linked / '.taskq').exists(), 'reuse writes nothing'
    shared.write_bytes(b'changed')
    with patch('urllib.request.urlopen', side_effect=AssertionError('invalid main checkout copy downloaded')):
        assert 'SHA-256 mismatch' in refusal(linked)
    assert shared.read_bytes() == b'changed' and not (linked / '.taskq').exists(), 'refusal repairs nothing'
    shared.unlink()
    with patch('urllib.request.urlopen', return_value=io.BytesIO(body)):
        assert lint(linked)[1] == str(own)
    assert own.read_bytes() == body and not shared.exists(), 'a download stays in the worktree'
print('PASS linked worktree reuses main checkout linter read-only; invalid copy refuses')

# R8/R12: only a certificate failure reaches curl, with validation intact; its bytes pass the same hash and its failure refuses.
import ssl
import urllib.error
untrusted = urllib.error.URLError(ssl.SSLCertVerificationError('unable to get local issuer certificate'))
done = lambda code=0, out=b'', err=b'': subprocess.CompletedProcess([], code, out, err)
with tempfile.TemporaryDirectory(prefix='taskq-lint-curl-') as directory, \
     patch.dict(gate, CONTRACT_LINT_SHA256=hashlib.sha256(body).hexdigest()):
    root = Path(directory)
    cached = root / '.taskq' / 'specq' / check['SPECQ'] / check['CONTRACT_LINT']
    with patch('urllib.request.urlopen', side_effect=urllib.error.URLError('offline')), \
         patch.object(subprocess, 'run', side_effect=AssertionError('offline reached curl')) as run:
        assert 'offline' in refusal(root) and run.call_count == 0
    with patch('urllib.request.urlopen', side_effect=untrusted):
        for result, expected in [(done(60, err=b'SSL certificate problem'), 'curl exit 60: SSL certificate problem'),
                                 (done(out=b'changed'), 'SHA-256 mismatch'),
                                 (FileNotFoundError('curl'), 'curl'),
                                 (subprocess.TimeoutExpired('curl', 15), 'timed out')]:
            with patch.object(subprocess, 'run', side_effect=[result]):
                assert expected in refusal(root), result
            assert not cached.exists(), 'unverified bytes never published'
        with patch.object(subprocess, 'run', return_value=done(out=body)) as run:
            assert lint(root)[1] == str(cached)
        command = run.call_args.args[0]
        assert command[:2] == ['curl', '-q'] and command[-1].startswith('https://raw.githubusercontent.com/taskqorg/specq/')
        assert not {'-k', '--insecure', '--cacert', '--capath'} & set(command) and run.call_args.kwargs['timeout'] == 15
    assert cached.read_bytes() == body
print('PASS certificate failure falls back to validating curl; invalid bytes and failures refuse')

# R8/R12: lint runs once before every other check; findings stop the gate.
with tempfile.TemporaryDirectory(prefix='taskq-lint-gate-') as directory:
    command = [sys.executable, 'fixture-linter.py', 'taskq.md']
    for status in (0, 1):
        with patch.dict(gate, ROOT=Path(directory), changes=lambda _: ['README.md'], rule_gate=lambda _: None,
                        contract_lint=lambda: command), \
             patch.object(sys, 'argv', ['check.py']), \
             patch.dict(os.environ, {}, clear=True), \
             patch.object(subprocess, 'run', return_value=subprocess.CompletedProcess(command, status, 'fixture lint\n', '')) as run:
            try:
                check['main']()
            except subprocess.CalledProcessError as error:
                assert status == error.returncode == 1
            else:
                assert status == 0
            assert run.call_args_list[0].args[0] == command
            assert sum(call.args[0] == command for call in run.call_args_list) == 1
            assert run.call_count == (7 if status == 0 else 1), run.call_args_list
            assert sum(call.args[0] == [sys.executable, 'scripts/batch-replay.test.py']
                       for call in run.call_args_list) == (1 if status == 0 else 0)
print('PASS lint runs first and once; findings stop before tests/builds')

# A1 of #2427: evidence, finished reviews and release records never return to the tree.
assert check['tree_evidence'](['docs/evidence/1/a.json', 'docs/design/evidence/1/a.png', 'docs/shots/evidence/1/a.png', 'docs/reviews/a.md',
                               'docs/design/exploration/a.html', 'docs/qualification-1.md', 'docs/release-1.md']) == [
    'docs/evidence/1/a.json', 'docs/design/evidence/1/a.png', 'docs/shots/evidence/1/a.png', 'docs/reviews/a.md',
    'docs/design/exploration/a.html', 'docs/qualification-1.md', 'docs/release-1.md']
assert not check['tree_evidence'](['docs/research/2395.md', 'docs/shots/manifest.json', 'tests/fixtures/usage/windows-oauth-usage.json'])
print('PASS tree guard refuses evidence paths and keeps research notes and fixtures')
