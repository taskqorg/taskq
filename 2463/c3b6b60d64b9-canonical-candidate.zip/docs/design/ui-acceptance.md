# UI implementation acceptance

[Shared process](https://github.com/taskqorg/specq/blob/main/design/implementation-fidelity.md) · [rendering rules](rendering-contract.md).
Historical release review: [4.1.9 audit](https://github.com/taskqorg/taskq/blob/96064118e637ea8d7347edc4ca50c5c5da186757/docs/design/release-4.1.9-ui-audit.md). No current release is accepted against this target yet.

## Workflow

1. Builder reads taskq.md and package index, follows [F1](https://github.com/taskqorg/specq/blob/main/design/implementation-fidelity.md#f1-source-and-change-control) and lists unsupported decisions before implementation.
2. Builder completes the ledger and supplies the [F5](https://github.com/taskqorg/specq/blob/main/design/implementation-fidelity.md#f5-acceptance-package) package; each row names its fixture and navigation route.
3. Reviewer checks functionality/data first, sizing/navigation second, natural-size rendering third; findings use the F5 fields.
4. Polish, owner review, freeze and acceptance follow [F6](https://github.com/taskqorg/specq/blob/main/design/implementation-fidelity.md#f6-build-polish-accept); native evidence qualifies the implementation.

Use [synthetic expected fixtures](../../tests/fixtures/ui-acceptance-fixtures.json) for histogram, sizing-boundary and lattice checks; these are inputs, not native proof.
Use [report template](ui-acceptance-report.md). Keep reports per candidate; do not overwrite failing evidence. Fixed items link replacement evidence.
Reports: [4.2.0 candidate on macOS](https://github.com/taskqorg/taskq/blob/96064118e637ea8d7347edc4ca50c5c5da186757/docs/design/evidence/g8-macos/report.md).

## Feature ledger

Builder completes the ledger per [F6](https://github.com/taskqorg/specq/blob/main/design/implementation-fidelity.md#f6-build-polish-accept). Each TaskQ row records initial, success, failure/unknown and recovery evidence where applicable.

| Surface / route | Must preserve | Requirements |
|---|---|---|
| Tray Icon/Summary/Custom | q, square type/grid, all-series cadence, gray pause overlay, partial/unknown | I1–I5, R-UI4/5 |
| Home top / Controls | named host, admission, pause review; urgent controls stable | M1/M5, M-A4/16 |
| Work mode | originals, interpretation, applied state; Mixed; explicit targets; CPU/memory and all runtimes | M4/M12, M-A9/20 |
| Attention / task | questions, failures, permission requests, service faults distinct | M-A7/10/21, P5 |
| Aggregate / projects | all states, Human=Ask, Held; dedup/partial | K-A1–K-A7 |
| Pinned/recent / All | stable order, search, complete registered list, add beside header | M-A2/18 |
| Project / tasks | Board at top, full flowing titles, issue/PR/local-session targets, remote host no-link | D-A1/2, M-A3/17 |
| Cadence detail | four series, totals, period/custom timezone, unavailable history | M-A5/6, R-UI4/5 |
| Menu composer | target context, attach/drop, history fill-only, Send opens conversation | M-A13/19 |
| AI workspace | selected conversation, drafts, active/archived lists, search, all C4 states | C-A1–C-A10 |
| AI windows | main/explicit detach, raise owner, recovery, no duplicated launch | C2/C-A2 |
| Conversations task/session history | accepted attempts, source model/effort or unavailable, live/ended, exact event targets and valid local links | C6/C-A8, unified reader |
| Setup | picker cancel, new/existing/old/nonrepo, exact external effects, empty-install gap | M-A14 |
| Appearance | theme, 14/16/18/20, Icon/Summary/Custom, persistence; no icon scaling from text | D-A3–D-A8 |
| Plans | four editable recipes, held creation, explicit start, dependencies and partial retry | UC-03/06/07, D06/D08/D14, G2/G5 |
| Auto resources | shared host admission, optional caps, fresh load, wait reasons, effective readback | UC-04/12, D03, G3 |
| Delivery | separate commit/push/PR/merge policy, candidate revision and checks, publication receipt | UC-14, D04, G4 |
| Remote PM | project routing, opt-in watch, source-numbered answers, media and gateway recovery | UC-17 |
| Agents | probes, accounts, versions, disabled runtimes, effective policy/source | M9, P-A1–P-A10 |
| Services | freshness, logs/folder, incidents + disclosure/consent, Resources | M-A10–M-A12 |
| Emergency / recovery | named host, owned-process stop, durable hold, preserved work, selected fenced restart | E-A1–E-A9 |
| Lifecycle | pause/restart/stop/uninstall differences, named targets, confirmation/readback | M-A4/11/12 |
| About/update | tray/service/host versions, availability/progress/failure/rollback | M9 |

Permission, AI and remote extensions remain gated by their unimplemented or unqualified backend contracts. Accepted product direction does not resolve those engineering gates. Do not mark their overall row Pass from a mock.

## Native matrix

The full matrix runs only for release qualification and README shots; a task's check captures only the routes its diff changes (`taskq tray --snapshot DIR --route R,..`, [taskq.md R12](../../taskq.md#r12-unverified-means-unknown)).

- macOS WKWebView + installed menu-bar icon; Windows WebView2 + installed notification-area icon. Same fixture revision.
- Both themes; 14/16/18/20 px. Windows scale 100/125/150/200%; macOS actual 1×/2× displays where supported. Unsupported/unavailable cells explicitly Not tested.
- Windows 1366×768 and 1920×1080 work areas; bottom/top/side taskbar; secondary monitor with different DPI. macOS ordinary/notched menu bar, Dock reservation and external monitor.
- Empty, one project, 20 projects; 0/1/12/100/1000 counts; 180-character titles and long unbroken identifiers; stale/mixed/fully paused.
- Fixtures: content needs 95% and 100% of usable height; content exceeds anchor-side space but fits after repositioning; content fits by 1 pixel; equals available height; exceeds by 1 pixel; becomes smaller after collapse; async content grows; font changes while a field is focused.
- Counter/graph cases: closed-only, failed-only, ask-only, blocked-only, equal mixed stack, zero middle bins, nonzero edges, duplicate events, period boundaries, incomplete history.
- Graph time sequence: two refreshes within one bin, exact next boundary, late event and range change. Verify a frame sequence; a still image cannot prove motion.

## Hard gates

| ID | Pass condition |
|---|---|
| U-A1 | Every ledger route reachable; no unapproved omission; real effects verified separately |
| U-A2 | Natural content fits: no primary scrollbar; overflow: one intended scrollbar and reachable last control |
| U-A3 | Usable-area clamp, anchor/DPI conversion and resize/collapse correct on both OSes |
| U-A4 | Header/footer/composer never overlap content; focus/draft/Back position preserved |
| U-A5 | Histogram totals and series agree across adapter, tray and detail; no active-count substitution |
| U-A6 | Integer bar bounds, equal widths/gaps, shared baseline; approved temporal shift and rebin semantics |
| U-A7 | Icon shape/font/grid/pause match I1–I5 at native size; unknown/overflow policy explicitly accepted |
| U-A8 | Keyboard, accessible names, contrast and large text verified in native renderer |
| U-A9 | Existing 4.1.9 additions retained or explicitly superseded; proposed improvements resolved |
| U-A10 | Frozen artifact evidence complete; changed reference requires owner acceptance, not screenshot regeneration alone |

Native click and window-raise behavior (a tray click, Send or Reopen raising a window) is owner-observed: the owner uses the tray daily and reports defects as tasks. It is not a required acceptance gate, and no task waits on a real-user click or raise proof. Source, model and browser checks of the same behavior stay required.

Blocking: wrong data/action target, duplicate side effects, lost series/features, clipped essential controls, unjustified scrolling, unreadable icon or unapproved semantics. Minor platform font antialias differences may be documented; geometry and behavior still pass.

Summary: [I1–I6](icon-summary.md), including identical six-bin SVG groups on all surfaces, palette A, exact/incomplete detail and native size/state qualification. [Custom compatibility](custom-icon.md) retains saved settings.

## Contract detail

Moved verbatim from `taskq.md` (#1179) to keep the contract under its R8 size bound. `taskq.md` keeps the decision and links here; this text keeps the same authority (R8, R13).

Follow [shared verification rules](https://github.com/taskqorg/specq/blob/main/engineering/verification.md). TaskQ readback and platform obligations are specified in §§4–8. Merge checks follow [test selection](../testing.md); native/visual acceptance remains separate. The [runtime qualification matrix](../runtime-qualification.md) is the bounded live acceptance, rerun only when its runtime path, permissions or client version changes; it is not a per-commit gate. Do not duplicate matrix evidence with command-string assertions. Design prototype tests under `docs/design/` are development instruments: not in CI, not a handoff requirement, and they write evidence only on request. Browser instruments (`tests/*.browser.cjs`, prototype tests) launch through `tests/browser.cjs`: Playwright's chromium headless shell by default; `PLAYWRIGHT_CHANNEL` picks an installed browser outside a worker only, and a worker (`TASKQ_TASK` set) ignores it with one log line, because the Google Chrome app aborts at startup under the macOS service and leaves a crash dialog. GUI runs on macOS (tray, snapshots, notifications) start the signed build through cargo ([signing](worker-permissions.md#macos-signing-identity)) and never trigger a TCC prompt; a prompt is a failure to report in the result or `ask`, never one to click or dismiss. Tray screenshots run only when a check needs them and capture only the routes the diff changes (`tray --snapshot DIR --route R,..`); the full matrix (every route, both themes, 16/20 px; [native matrix](ui-acceptance.md#native-matrix)) runs only for README shots and release qualification.
- Screenshots: dark theme from `taskq tray --snapshot` over `docs/shots/fixture.sh`; `docs/shots/manifest.json` pins version, commit and hashes; CI marks shots stale when recorded UI source blob ids or capture-input hashes differ from HEAD (a warning, not a failed check; task branches never commit them, [visual evidence](../testing.md#visual-evidence)), while a missing or malformed manifest (whole JSON parsed first), a README image it lacks or a listed image that is missing, not a PNG or differs from its hash fails; each release dispatches the README shots workflow for its tag, which proposes a stale set as a draft PR through the merge queue, never a push to main and never on every tray push. Present images individually at readable widths with complete framing; inspect the rendered page at desktop and narrow widths and retain before/after evidence for owner acceptance before publication.
