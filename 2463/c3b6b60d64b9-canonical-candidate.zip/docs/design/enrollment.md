# Independent DashQ connection

Accepted implementation target under [taskq.md](../../taskq.md). Apply [shared connection semantics](https://github.com/taskqorg/specq/blob/main/engineering/product-connections.md) through the coreq linked client and [DashQ C1–C7](https://github.com/taskqorg/dashq/blob/main/docs/design/enrollment.md). Implemented (#913); release qualification below.

`taskq enroll <https-url>`, `taskq connection status` and `taskq disconnect` use the same browser/headless approval, protected credential, projection receipt and revoke lifecycle as AgentQ. No AgentQ installation dependency. The existing service handles delivery; no extra daemon or scheduler. Stable random installation identity survives updates, never derives from hostname; lost identity creates a new installation.

Send only a coalesced latest unsent snapshot. Connection state and credentials are durable and excluded from pruning; they contain no authoritative product state. Heartbeat freshness and underlying observation freshness remain separate. Snapshot transport failure never changes primary command success or blocks primary work. C3's accepted credential lifetime exception is confined to observation, never commands or forge access.

## TaskQ projection

The canonical snapshot remains the only board projection; reuse its revisions, task IDs, card choices, recommendation and completeness. Explicitly approve board scope in enrollment and show it before switching. Forge tokens remain local. Coalesce per board without summing duplicate board snapshots from several hosts; installation identity and board identity are distinct.

R1 exception: protected connection identity/grant/revoke state, the [host link](host-link.md) key `<install>/link-key` and the latest unsent projection may live locally; they are not task truth, logs or an offline task queue. Board mutations still follow canonical actor/revision/op-ID/receipt rules. This observation grant cannot answer questions or execute commands. Remote PM requests require the separate [PM exchange and host grant](pm-requests.md); resource grants never authorize PM launch.

## Prepared projection (#912)

`src/enrollment.rs` prepares schema 1 observations; no command or service delivery is enabled yet. `installation_id(install)` creates a random 256-bit lowercase hex `installation-id`, publishing a complete file without replacing a concurrent winner. Updates and data pruning keep it; corruption is an error and stays untouched. Only a missing file creates a new identity. It is not a credential or host identifier.

An exact approved `(kind, host, repo)` scope gates projection of an unfiltered canonical snapshot. Identity fields are validated, host names and GitHub repository names lowercased; GitLab repository spelling stays canonical from the snapshot. No snapshot URL or extra identity keys are copied. Allowlisted task fields are number, state, revision, numbered choices and recommendation from the canonical card parser, plus `admission` of ready and waiting tasks and of reviews awaiting a reviewer ([contract detail](#contract-detail), #1616, #1685). Choices are explicitly scoped board content. Titles, raw cards/reasons, session ids, labels, paths, host metadata and configuration are omitted. A live attempt on the sending host adds `session` (R6 3, #1565): `host`, `runtime`, `stage` (`doing`/`review`), `at` (attempt log update time) only; worker text never leaves a host readable; host link pages are end-to-end encrypted (#1617, [host link](host-link.md)), and local session views keep their own display. Stored snapshots holding an older `line` age out normally. Incomplete observations carry a fixed reason, never raw forge diagnostics.

Coalescing selects one latest observation per approved board, irrespective of installation; totals are never added across hosts. Equal-time conflicting observations become explicitly unknown. Every approved board gets a row, including missing observations. Freshness uses the original board observation time and the caller's maximum age; future/zero times are unknown, old observations are stale, and unknown/stale totals are null. Completeness remains independent of freshness. This is an observation adapter, never a task-state source or offline command queue.

## Client (#913)

coreq v0.11.0 `enroll` owns pairing, protected state (`<install>/connection/`, kept by sweep and pruning), delivery, receipts and revoke; TaskQ adds no transport. The request carries the TaskQ `installation-id`, product `taskq`, the host name as label, schemas `taskq-board/1` and `taskq-resources/1` ([project limits](shared-resource-controls.md#project-overlay)), plus `taskq-telemetry/1` with `--telemetry` ([remote sync](standalone-telemetry.md#remote-sync-1353)), scope `{name: taskq-board/1, value: <kind>:<host>/<repo>}` and no capabilities. One board per installation: enrolling another project's board shows `old -> new` and switches; the old grant is revoked. A bare DashQ origin gets `/machine` appended.

Each service pass hands its latest snapshot to one delivery thread; a projection equal to the last accepted one is resent only after 300 s. Only the root whose board equals the approved scope sends. Retry follows coreq backoff; a stop (401, refused batch) waits 300 s; outcomes go to the service log and `status.json` `connection`. On a host-policy install the same batch carries the `taskq-resources/1` record when the grant lists it. Choice text is `label` (DashQ C4 refuses a `text` key); over 256 tasks the observation is incomplete, reason `task limit`.

## Qualification

Prove an independently installed product can enroll, show a real matching snapshot in DashQ, recover after network/store restart, disconnect offline, revoke and reconnect without identity or scope leakage. Test denied/wrong-workspace requests, lost replies, bounded storage, schema compatibility and primary-function independence. Reuse coreq conformance; do not reimplement its auth or transport. Ship only after applicable E1–E10 and the product's normal checks pass.

| DashQ case | TaskQ evidence | Open |
|---|---|---|
| E1 connect | live macOS desktop enroll and fresh macOS and Windows `--headless` enrolls to dash.ufobe.com: approved code, first snapshot `projected`; DashQ 0.9.2 `/data` shows the `taskqorg/taskq` `taskq-board/1` snapshot (owner readback, #913) | — |
| E2 cancel/expire | live expired code ends with the rerun step; deny and wrong code are coreq conformance | — |
| E3 crash mid-pairing | coreq keeps `pending`; a rerun resumes it (coreq conformance) | — |
| E4 outage | chain `sender_sends_only_the_approved_board_and_never_blocks`: delivery on its own thread, outage only waits | — |
| E5 forged/wrong scope | same chain: another project's board is never sent; capabilities none. Live probe on DashQ 0.9.2 under the `taskqorg/taskq` grant: a `taskqorg/coreq` record is `rejected`, reason `scope`, and its receipt is `unknown_event`; the same record for `taskqorg/taskq` is `projected` | — |
| E6 schema | `taskq-board/1` projection fixture test | — |
| E7 disconnect | live macOS and Windows: revoke confirmed, `connection status` none, second disconnect says none; offline disconnect queues the revoke for the service, a repeated disconnect retries it and reports it pending or confirmed, never none; disconnect during pairing cancels it, revokes a staged grant, `enroll` cannot resume it (chain check `disconnect_cancels_pending_pairing`) | — |
| E8 TaskQ alone | no AgentQ dependency (Cargo.toml) | — |
| E9 upgrade | chain `identity_survives_pruning_and_concurrent_creation` keeps `connection/` through sweep and pruning; installed 4.2.0-dev sweep deletes it until this release | — |
| E10 UI | DashQ page; not TaskQ | — |

A worker cannot write `<install>` under the § 8 Access profile, so live enrollment runs from the owner's shell, a Full grant or a disposable `TASKQ_INSTALL`.

## Contract detail

Pairing and revoke: `disconnect` cancels a pairing in progress and stops sending at once; the service retries an unconfirmed revoke. Snapshot host observations below carry producer, host, time, `valid_until` and `complete`; missing or expired reads unknown.

Host observations (#1507) for the DashQ host-first view: every `taskq-board/1` snapshot carries `observations`, one object per `(host, kind)` with kind `online`, `login` or `queue`. Scope is the approved board plus the host name; a host is any host with a § 4 heartbeat plus the sending host. DashQ reads these objects and never infers a host state from activity, silence, missing rows or board totals. Each object names `producer` (the 12-hex service id of the heartbeat for `online`, else the sender's; null when unknown), `observed` (Unix seconds of the board read for `online`/`queue`, of the runtime probe for `login`), `valid_until`, `state`, `complete` and a fixed `reason` (null when complete).

| Kind | Producer, time, validity | States and cases |
|---|---|---|
| `online` | heartbeat service; board read time; `observed + ttl`; also `heartbeat` (its update time) | `online`: heartbeat age ≤ ttl. `offline`: older. `unknown`: no heartbeat or unknown time. Partial: heartbeat without a `service` line, `complete` false, reason `no service identity` |
| `queue` | sender service; board read time; `observed + ttl`; counts `running` (doing/review attempts whose session names the host) and `queued` (ready/waiting tasks labelled `host-<name>`) | `busy`: running > 0. `idle`: none running (`queued` may be > 0). `unknown`: incomplete board read, counts null. Partial: over 256 tasks, `complete` false, reason `task limit` |
| `login` | sending host only; probe time; `observed + 600`; one key per runtime with `logged in`, `not logged in`, `not installed` or `unknown` | `logged in`: no runtime is logged out. `not logged in`: one is logged out, or none is installed. `unknown`: no probe yet. Partial: a runtime reads unknown, `complete` false, reason `runtime login unknown` |

Other hosts' logins come from their own installations. TaskQ only writes these objects; a reader (DashQ) keeps the latest object per `(host, kind)` across installations of the board. A kind missing for a known host reads `unknown`, reason `no observation`. An object past `valid_until`, or without one, reads `unknown`, reason `expired`, counts null and runtime logins `unknown`. Missing or expired is never `online`, `logged in` or `idle`. Fixture: `tests/fixtures/host-observations.json` (test `host_observations_match_the_fixture`).

Admission (#1616) for DashQ and the tray: `status --json`, `status.json` and `taskq-board/1` rows of `ready` and `waiting` tasks carry `admission` from TaskQ's own decision; other rows carry none, and the change is additive. Each object names `code`, `observed` (Unix seconds of the board read the decision rests on) and `host` (the deciding host; null for the board fold or when no host decided). `status --json` and `status.json` add free-text `reason`; `taskq-board/1` keeps `reason` only for `unknown`, from a fixed list. Consumers read the code and never infer a reason from silence, activity, labels or board totals.

| Code | Decided by | Case |
|---|---|---|
| `dependency` | board fold | `waiting`: a § 1 `Depends on` issue is open or unknown |
| `admitted` | service pass | claimed in this pass; the next read shows `doing` or `review` |
| `hold` | service pass | emergency hold, draining project, pending restart or an older service on the host |
| `host` | service pass | `host-*` label for another host, labelled claim without a label, or `assignee-only` without this board user |
| `capability` | service pass | a `needs-*` label, `needs-gui` without a Full runtime, or a routed runtime this host lacks |
| `labels` | service pass | conflicting labels; no host admits the task |
| `focus` | service pass | focus off or unreadable, or the task outside a non-`all` focus (p0 passes) |
| `capacity` | service pass | runtime, project or host slots full, runtime not in Fixed limits, or another project's round-robin turn |
| `load-gate` | service pass | the load gate or 30 s launch spacing |
| `login`, `usage-limit`, `access` | service pass | the routed runtime is logged out, held after a usage limit, or refused its access grant |
| `unknown` | anyone | `no host decision` (a CLI board read, or a row the pass did not reach), `capacity config unreadable`, `host admission unknown`, `execution unresolved` |

The first refusal in step 6 order wins; after a refused host reservation the rest of the queue reads the same code. `status --json` reads the board, so its `ready` rows read `unknown`, reason `no host decision`; the deciding host's rows are in its `status.json` and its `taskq-board/1` snapshot. Fixture: `tests/fixtures/admission-codes.json` (test `admission_codes_match_the_fixture`); service chain `ready_rows_carry_this_hosts_admission_decision`.
