# Worker permissions

Product selection: D05 option 1 is accepted in the [decision register](decision-register.md).

P1–P4 and the P7.6 rollback floor are implemented (#970) as taskq.md R9 and § 8 Access: macOS enforcement and explicit-project Linux Codex enforcement ([launcher](linux-sandbox.md)); other platform/runtime pairs refuse non-Full presets. The rest stays design input.
Shared candidate: [permission authority](https://github.com/taskqorg/specq/blob/main/engineering/permission-authority.md).
Applies to workers, reviewers and the full operator (R3/R9); tools remain bounded by effective runtime permissions and the owner request.

## Shipped enforcement

Moved from taskq.md § 8 Access, which keeps presets, authority and refusal rules.

- macOS wraps the child in a taskq Seatbelt profile; Codex's own `read-only`/`workspace-write` cannot nest, so legacy Codex keeps it (only one sandbox choice, model, network access and added dirs; none of them nor the root above `<install>`) and a preset runs `danger-full-access` inside taskq's profile. Its `workspace-write` keeps `<cwd>/.git` read-only, so when `<root>/.git` is a real directory taskq adds its `objects`, `refs`, `logs`, `worktrees`, `packed-refs`, `packed-refs.lock` and `packed-refs.new` as writable roots, unless one is a link. Git in a linked worktree can then fetch, commit, rebase and push. `config`, `hooks` and `info` stay read-only, so `git push -u` cannot write upstream config. Another project's `.git` and `<install>` stay refused. `taskq doctor` `codex-git` names a Mac Codex launch without that root. A job under a shared daemon inherits the daemon's profile instead: [one sandbox per daemon](#one-sandbox-per-daemon).
- Linux Codex Restricted/Workspace uses the root-owned `taskq-sandbox` launcher and private bubblewrap backend ([setup and boundary](linux-sandbox.md)); the outer process boundary and native read-only/workspace-write both remain enabled, never Full. Linux protects active runtime configuration and the project `.codex` directory; its explicit project grant is required.
- Windows Codex Workspace refuses start and resume before preparation: no native dependency currently has completed containment qualification ([qualification matrix](../runtime-qualification.md)). An explicit project grant or a historical binary hash cannot enable this path. Restricted and narrower requests remain unavailable; no Full fallback. The retained preparation and identity-bound restoration code does not qualify launch.

Windows Workspace must contain native deletion, replacement and rename as well as writes, including another approved workspace and reparse aliases. A restricted-token bootstrap may lower only its SDK-owned private desktop and its own token to Low integrity; the default desktop and window station stay unchanged. Only approved mutable workspace/temp/runtime-data objects may become Low. Installation, runtime home parent and executable/configuration/authentication controls remain Medium. Preparation journals original identities, ownership, DACLs and mandatory labels before effects; rollback restores security only for matching identities and unchanged applied security, preserving live data and concurrent edits. Unknown security or mutable SQLite reconnect behavior refuses admission; a version probe or Medium-canary denial does not qualify this boundary.

The pinned Windows adapter prepares mutable home directories `sessions`, `archived_sessions`, `log`, `shell_snapshots`, `memories` and `tmp`; its named SQLite databases and WAL/SHM files, JSONL indices/history and maintenance lock are data. It never synthesizes JSON caches or rewrites database contents. The Medium home parent denies ambient `FILE_DELETE_CHILD`; SQLite WAL/SHM deny `DELETE` so unrestricted client closure cannot remove the Low files needed for reconnect. Owner configuration edits still use the target's own delete permission. These sidecar denies can delay SQLite closure; the qualified runtime must exercise that lifetime. The protected installation's `windows-native/security-preparation.json` retains security preimages and applied state. An unrestricted operator may run `taskq __windows-security-restore <install>` with the host held and fixture/native descendants idle; it restores matching saved identities only, never file bytes or replaced files. A crash during SDK preflight can leave an unobserved ACL change: admission and automatic restoration then refuse, retaining the original journal for manual review. No forced close or guessed ACL restoration. Label-only null unprotected SACL and absent SACL both mean no mandatory ACE; other label/inheritance/protection differences remain conflicts.

Protected external Codex app-server consumers use the same project Workspace resolver and Seatbelt through the [host adapter](protected-app-server.md#contract-detail). The existing policy store remains the only grant authority; its receipts describe observed enforcement, never grant access.

## Rollback floor

Older versions (4.1.11) ignore grants, run legacy flags and their update sweep deletes the store; this is why taskq.md § 8 Access holds `previous` at the floor `4.2.0-dev`.
A manual downgrade below the floor is the operator's and runs legacy flags. To keep grants, copy the store outside `<install>` and stop unless the copy matches; coming back, `service pause` each project, `taskq update` (the old version sweeps on it), copy the store back and `service resume` only after `service permissions` reads the grants back.

## macOS signing identity

Moved from taskq.md § 8 step 5 (#1089). This identity is the current macOS signer of the [signing step](../../taskq.md#install-and-signing); its certificate leaf below is the step's requirement until that step changes. TCC keys an ad-hoc Screen Recording or Accessibility grant to the cdhash, which changes with every release. With the identity `TaskQ Local Signing` (a self-signed code-signing certificate in the login keychain, no trust setting) `service install` and an update re-sign the launcher and the new release as `org.taskq.taskq` through a copy renamed into place, the tray signs `TaskQ.app` with it, so one grant matches every later release (identifier and certificate leaf, verified after each signature). Without it they stay ad-hoc and the log says so; a failed signature or verification is logged per copy, which stays ad-hoc. Local builds follow the same rule (#1329): on macOS `.cargo/config.toml` starts `cargo run` and `cargo test` binaries through `scripts/macos-runner.sh`, which runs `taskq sign-local` (the same `platform::codesign`) on the binary and on the `taskq` beside it before exec, so worker GUI checks and `scripts/dev-install.sh` run builds that match the release requirement. Without the identity it logs once per target directory and they stay ad-hoc; a failed signature fails the run. Run a binary from `target/` only through cargo, never directly.

Bundle trap (#1395). TCC keys the service grant by its launchd program `<install>/taskq` and checks the stored code requirement against that file. Because the executable `taskq` sits in a directory named `taskq`, macOS reads `<install>` as a flat bundle as soon as it holds a `Resources` entry (any case): `codesign -v <install>/taskq` then fails with `code has no resources but signature indicates they must be present`, tccd logs `Failed to match existing code requirement for subject <install>/taskq` and every capture prompts again, whatever the owner toggles. So no `<install>` entry is named `Resources` or `Contents` in any case; the resource store is `<install>/resource-state` and an old `resources` store moves there on first use, and one an older host recreates after the move goes to `resource-state/superseded` when the next service owns the host. `scripts/macos-tcc-evidence.sh` prints the read-only evidence. Agents never edit TCC.db, run `tccutil` or click a prompt; a prompt during agent checks is a failure.

Stale grant (#1803). A grant given while `<install>/taskq` was ad-hoc, or before the bundle trap was fixed, stores a requirement pinned to that binary's cdhash. Every later release fails it: tccd logs `Failed to match existing code requirement for subject <install>/taskq` although `codesign -v` passes, and turning the Settings switch off and on keeps the old requirement. Detection: the service's gui probe reads the Screen Recording preflight as denied while `<install>/taskq` meets the stable requirement (`org.taskq.taskq` and the `TaskQ Local Signing` certificate leaf); status reports `gui.stale_grant` and the tray posts one notice with the owner step, recorded in `tray.json` so it never repeats until a passing probe ends the episode. `scripts/macos-tcc-evidence.sh` labels such tccd lines and cdhash-pinned TCC.db rows `stale grant`, and the same lines with a failed `codesign -v` `bundle trap`. One owner step: in System Settings > Privacy & Security > Screen Recording (and App Data when listed) select taskq, remove it with `-`, then allow taskq at the next prompt; the new row stores the stable requirement. The gui probe captures only after an allowed preflight, so a stale grant never raises a prompt from the service; a `needs-gui` task waits ([GUI eligibility](../runtime-qualification.md#gui-eligibility-contract-detail)).

Accessibility and App Data (#1845). The same stale requirement hits Accessibility and App Data (`kTCCServiceAccessibility`, `kTCCServiceSystemPolicyAppData`). The gui probe also reads `AXIsProcessTrusted` (no prompt) and one `log show --last 1h` of tccd `Failed to match existing code requirement` lines for `<install>/taskq`. `status.json` `gui.grants` reports `screen_recording`, `accessibility` and `app_data`, each `allowed`, `missing`, `stale` or `unknown`: Accessibility is `stale` when denied with such a tccd line, else `missing`; App Data has no preflight API, so it reads `stale` on such a line and `unknown` otherwise (R12), never `allowed`. A `missing` or `stale` Accessibility or App Data grant holds `needs-gui` launches with the wait reason `<grant> grant <state> (TCC)`, and the tray posts one notice per grant and episode, recorded in `tray.json` `grants`, ended by a pass where no status reads it `missing` or `stale`. Owner step: System Settings > Privacy & Security > Accessibility (or App Data): for `stale` select taskq and remove it with `-`; then add `<install>/taskq` with `+` and switch it on. Workers never ask the owner for a TCC grant: the brief tells them to report a denial in the result `Open`; the service owns the notice.

## Evidence and #865

- Inspected checkout: `cfae06708776d252d52f31510afed6b47918cee6`. `src/runtime.rs::command` passes project `permission_mode` to Claude and project `codex` arguments to spawn/resume. `src/main.rs` defaults to `dontAsk` / `danger-full-access`. No independent host ceiling.
- [#865](https://github.com/taskqorg/taskq/issues/865), closed through [#866](https://github.com/taskqorg/taskq/pull/866): worker `find /` for missing taskq.md caused folder prompts attributed to taskq. Report cites tccd timing and worker transcripts. This review read the report, not those original logs.
- Result `1ed9efc442a1b5f6108ebefa27ed11929ac84a87`, merge `c933c2c6925718c376afae86df4b20be5ad317b3`: briefs name an existing release contract and forbid broad searches. Runtime sandbox was explicitly not enabled because R9 preserved permissions. Owner confirmation after restart remains open.
- Upstream §8 Folders names root/install/runtime homes/temp and an owner-picker exception. The inspected checkout predates that change. Preserve the fix when merging; do not overwrite newer upstream text.
- Closing #865 does not prove containment ([permission authority](https://github.com/taskqorg/specq/blob/main/engineering/permission-authority.md)) or absence of future TCC prompts.
- [coreq trust rule](https://github.com/taskqorg/coreq/blob/main/coreq.md): agent-writable project configuration must not choose executable code. Apply the same trust distinction to permission escalation.

## P1 Recommendation

Small preset vocabulary; explicit effective boundary beneath it. No runtime flag editor in the primary menu.

| UI / stored mode | Intended work | Boundary |
|---|---|---|
| Read only / `restricted` | Research, inspection, review | No project writes; private runtime/temp writes still needed |
| Workspace / `workspace` | Edit, build, test | Writes to approved workspace set; network separately controlled |
| Full / `full` | Operator-trusted unrestricted automation | Runtime sandbox disabled; OS/admin policy still applies |

Workspace is the proposed new-install default, only where qualified. Unsupported enforcement blocks admission; never fall back to Full.
The owner's isolated runner can use Full after one host-level approval. No per-task nag for unchanged grants.
Show `Full · VM isolation verified`, `Full · runtime sandbox off`, or `Isolation unknown`. A checkbox claiming a safe environment is not verification.

| Alternative | Benefit | Cost / decision |
|---|---|---|
| Raw flags per project | Exact runtime controls | Easy escalation, poor comparability; reject as authority |
| Three presets only | Small UI | Hides network/path differences; insufficient alone |
| Presets + effective details | Simple common path, inspectable exceptions | Recommended; adapter qualification required |
| Mandatory external isolation for every job | Strongest uniform boundary | More setup and OS work; required when strict containment cannot be proven natively |

## P2 Owner, precedence and trust

`effective = intersection(admin ceiling, host grant, project restriction, task restriction, runtime capability)`.
Modes are shorthand; compare permissions as capabilities, not just ordered strings. Paths/tools/network form separate sets.

| Layer | Who controls it | Can raise? |
|---|---|---|
| OS / managed runtime policy | System administrator | Outside TaskQ; never bypass |
| Host default per runtime | Local operator | Explicit reviewed grant, within admin ceiling |
| Host-owned project override | Local operator; keyed by canonical project identity | Yes within admin ceiling; never inferred from repository contents |
| Project config | Project authors/agents | No; reduce capabilities or request more |
| Task constraint/request | Task author | No; reduce, declare required access, or ask |
| Runtime adapter | TaskQ with versioned capability probe | No; unsupported combinations refuse |

Absent restriction inherits; it does not grant. A request above the ceiling waits for an operator decision, not silent clipping followed by failure.
No automatic escalation via urgency, scope, labels, task answers, agent role, fallback runtime or old session.
Raising host defaults previews affected projects/runtimes. Local one-attempt grants bind project, task, host, runtime and next attempt; consumed once, cannot transfer on retry/migration.

Proposed store: host-owned `worker-policy.json` outside projects and worker-writable install/runtime paths. Authority channel authenticates the human operator independently of worker OS identity.
0600 is hygiene, not protection from a worker running under the same user. `taskq service permissions` alone is not authentication. Workers must not edit policy, impersonate tray confirmation, replace the service or invoke the grant broker.
Workspace/restricted profiles deny those paths and broker access. Full on the same host/user cannot offer this invariant against arbitrary worker code: show `operator-trusted`, or run workers under an isolated identity/VM and keep the broker outside. This is an explicit architecture gate.

## P3 Runtime catalogue

Local help: Codex 0.159.3, Claude Code 2.1.296. Pin adapter evidence to version/OS. Help is not execution proof.

### Codex

- `-s read-only`, `workspace-write`, `danger-full-access` select sandbox policy; approvals are separate.
- TaskQ unattended candidate: explicit sandbox plus `approval_policy=never`; denied operations become TaskQ decisions, not invisible terminal prompts. Full uses explicit host authorization.
- `--full-auto` is a deprecated compatibility flag in current documentation; do not use it as a stable preset or synonym for Full.
- `sandbox_permissions` is version/surface-specific capability configuration or tool escalation input, not a portable fourth preset. Local help accepts config syntax, but vocabulary and enforcement need adapter tests. Never forward arbitrary project values.
- Enumerate effective additional roots, network and protected paths. `workspace-write` alone does not prove reads are confined to root.
- codex-app needs separate proof: handshake policy and resumed app turn must retain the ceiling. Hide unsupported modes rather than assume CLI equivalence.

Sources: [sandbox/approvals](https://learn.chatgpt.com/docs/sandboxing), [CLI reference](https://learn.chatgpt.com/docs/developer-commands?surface=cli).

### Claude

| Native option | Meaning for TaskQ |
|---|---|
| `default` | Interactive approval; unsupported headless without an approval transport |
| `acceptEdits` | Auto-accept edits; other tools may still prompt; not equivalent to Workspace |
| `plan` | Planning behavior, not a complete OS read-only boundary |
| `dontAsk` | Deny would-be prompts; allowed operations still run; not Full |
| `bypassPermissions` | Skip permission prompts; not an OS/TCC bypass |
| `--allowedTools` / `--disallowedTools` | Tool permission rules; neither alone contains arbitrary shell/MCP side effects |
| `--tools` | Available tool surface; keep operator tools empty |
| `--add-dir` | Additional working paths; host-approved only, not independent containment |

Restricted/Workspace candidate: `dontAsk` plus host-generated tool grants and enforced filesystem policy; qualified shell/network behavior. Full candidate: `bypassPermissions` plus the explicitly selected isolation profile.
Sandbox is separate from permission mode. Enforce startup failure when unavailable and no unsandboxed retry; reject excluded-command escapes and project-supplied weakening. Native Windows needs a supported isolated runner for the same guarantee.
Sources: [permissions](https://code.claude.com/docs/en/permissions), [sandbox](https://code.claude.com/docs/en/sandboxing), [CLI](https://code.claude.com/docs/en/cli-reference).

## P4 Filesystem and environment

“Never leaves root” means access, not current directory. `current_dir(root)` is not a guard.
A working process also needs system libraries, executables, certificates, temporary storage and runtime state. Define read/write/execute grants separately.

| Resource | Intended grant |
|---|---|
| Root, owned worktree, Git common directory | Read; write only in Workspace/Full as explicitly resolved |
| UC-06 repository set | Explicit canonical members; external worktree path is a request, not authority |
| Runtime state and per-attempt temp | Minimal private writable paths; no blanket shared home grant |
| Release binary and bundled contract | Read/execute; never worker-write authority files, updater or policy |
| Build caches / package sources | Named grants, read/write scope, owner-visible exceptions |
| System runtime dependencies | Necessary read/execute; not arbitrary user data |
| Documents/Desktop/Downloads/iCloud, volumes, other app containers | No incidental discovery; explicit exception requires operator review and qualified enforcement |

Deny sensitive home data by default. Narrow injected credentials to required capabilities; do not pass the host policy broker credential. Runtime homes can contain credentials/hooks/config, so allowing all writes to them undermines the ceiling.
Canonicalize roots and constrain symlinks, junctions, mounts, child processes, hooks, MCP/plugins and resumed sessions. Revalidate before spawn; no raw project security flags or additive user config may weaken policy. If the adapter cannot prove the effective merge, refuse.
Network: `Off`, `Allowlist`, `Unrestricted`, bounded by the host grant. Full can restrict network only through an independently enforced external boundary; without it, report Unrestricted. Provider API transport and worker-tool egress are distinct. Show package download/publish requirements explicitly.

| Platform | Enforcement candidate | Qualification gap |
|---|---|---|
| macOS | Native runtime sandbox; Seatbelt-backed Codex/Claude shell boundaries | TCC is separate user-data consent, not a root allowlist; no automatic Full Disk Access grant |
| Linux / WSL2 | Supported runtime sandbox with available dependencies | Reads, children, sockets, mounts and network need negative tests |
| Native Windows | Qualified Codex native sandbox; separate Claude supported runner if required | ACL/reparse-point and child-process tests; no claim that Claude native sandbox exists |
| Isolated VM/container | Boundary around the whole worker, broker outside | Mounts, credentials, host sockets and network must match the declared profile |

Full without external isolation has no strict root boundary. Do not label it contained or promise no macOS prompts. Preserve #865's precise-contract lookup in every mode.

## P5 Denial and escalation

- Detect structured denial with tool/path/capability evidence. Do not label every nonzero exit an escape.
- End the blocked attempt through a fenced `ask`; preserve patch/logs. Queue state is Ask, not Failed. Retry only after a concrete disposition.
- Incident `worker.escape`: confirmed outside-boundary access attempt, outcome `blocked` or `breach`; distinguish from missing permission, TCC denial and unavailable sandbox. Store sensitive paths locally; public reports follow incident consent/redaction.
- Missing sandbox before spawn: admission blocked + service incident; no phantom attempt or failure count.
- Ask options: keep restriction/revise task; grant named capability once; change host/project grant; move to an eligible isolated host. Migration starts a new attempt under R2.
- A board answer requests a grant; it cannot authenticate one. Local review names the exact resource, host, runtime, duration and blast radius.
- Confirmed breach: hold new admission on the affected target, preserve evidence; terminate/quarantine only under an approved R11/emergency-stop amendment. Do not call this containment complete while a process can still run.
- Tightening policy affects new attempts. Mark existing sessions with their old revision; never silently resume an old broader session. Incompatible resume requires a new attempt or explicit refusal.

## P6 Operator UI and commands

Detailed workspace route and AS acceptance: [agent settings](agent-settings.md).

`Settings → Agents → <runtime>`: identity/version/account, effective mode, isolation, source, freshness. Disabled runtime remains visible.
Primary controls: `Read only | Workspace | Full`. Details: Files, Network, Tools, Project exceptions. Model/effort stay distinct; do not reset them while changing access.
Host shown once. Project exceptions inherit by default; list only exceptions plus Add. One review shows old→new, affected targets, active attempts unchanged. Cancel writes nothing.
Full review states `Runtime sandbox off` and actual external isolation evidence. No repeated confirmation for unchanged settings.
Permission blockage appears in Attention and the task, with `Review access` deep-linking to the exact request. Host policy never lives in the AI transcript.

Proposed CLI shape, not implemented:
```
taskq service permissions --host mac
taskq service permissions --host mac --runtime codex --mode workspace --review
taskq service permissions --host mac --runtime claude --project <registered-id> --mode full --review
```
Apply requires the authenticated local review channel and revision check; no public `--yes` route available to a worker. Local external editing imports a candidate through the same validation/readback, not a project-file grant.
`service status`: requested/effective mode, policy revision, source, sandbox/isolation proof, active-old-revision count, pending/unsupported reason. No credentials.
Spawn comment: mode + policy digest/version, additive metadata compatible with existing parsers; no local paths. Full audit also records actor, old/new, target, time and approval locally outside worker write access.
Saved is not Applied: completion and unsupported/stale values follow [shared verification](https://github.com/taskqorg/specq/blob/main/engineering/verification.md) on service readback.

## P7 Migration

1. Inventory raw `permission_mode`, `codex` args, runtime config sources, existing sessions and host identity. Never auto-import a dangerous grant from project files.
2. Show current resolved behavior beside proposed presets, exceptions and unsupported arguments. Preserve model/effort and unrelated config.
3. Operator approves a host policy; choose existing Full deliberately or a narrower profile. Approval is per host, not cloned with a repository.
4. New secure-policy release holds new admission until migration review; current attempts follow R11. This visible hold is a proposed rollout decision, not a change made here.
5. After compatible rollout, legacy project security fields become requests/restrictions only. Conflicts block with a migration explanation. Preserve originals for review; do not silently delete.
6. Old binaries ignore the new ceiling: drain/stop incompatible consumers through approved lifecycle, enforce a minimum policy-capable version, and prevent automatic rollback from launching an incompatible service. Roll back UI/code only to a compatible version; otherwise hold admission for operator recovery.
7. Verify spawn and resume for each runtime/OS, then resume admission. Share no host grants or private paths on the board.

## P8 Proposed taskq.md amendment

Apply with implementation and executable lifecycle traces, after owner approval. Current R9/§8/§9 remain runtime authority.

- R9 replacement: operator-owned host policy defines permission grants per runtime and optional registered-project override. Project/task input may narrow or request access, never raise it. Full requires explicit local approval, audited outside worker writes. Operator uses the same effective grants as the selected runtime, within the owner request; no tool-free exception.
- §8 Runtime addition: resolve and validate effective policy before spawn/resume; record revision/mode; refuse unsupported containment. Prompt-denied work enters fenced Ask. No in-place escalation or silent broader resume.
- §8 Folders replacement after reconciling #865: exact contract path, no broad discovery; access follows approved read/write/execute roots and runtime dependencies. Full is uncontained unless an independent boundary is verified. TCC consent is separate.
- §4/§5: status readback and local permissions-review command; policy decisions cannot be applied by the AI allowlist or a board answer alone.
- §9: remove project security options as grant authority after reviewed per-host migration; add compatibility floor for rollback. Preserve non-security runtime options.
- R1: host policy/audit is local operator configuration, not board task state. Board remains authoritative for Ask/attempt transitions.

## P9 Implementation acceptance

| ID | Required proof |
|---|---|
| P-A1 | Project/task text, config, CLI args, hooks and runtime merge cannot raise the host ceiling |
| P-A2 | Only authenticated local operator grants Full/exception; stale/replayed approvals fail; durable audit |
| P-A3 | Preset mapping proven for spawn/resume, workers/reviewers and codex-app separately |
| P-A4 | Negative read/write/child/network tests across roots, symlinks, Git common dir, homes and policy store on each supported OS |
| P-A5 | Sandbox unavailable fails closed; Full reports absent isolation honestly; no implicit TCC consent |
| P-A6 | Denial→Ask fenced once; missing capability vs escape vs breach distinguished; repeated delivery creates no extra grant/attempt |
| P-A7 | Status, tray and spawn agree on revision/mode; pending and active-old-policy are explicit |
| P-A8 | UC-01/03/04/06/07: setup, research, urgency, five repos and parallel workers respect independent grants |
| P-A9 | Migration preserves unrelated settings; no legacy auto-escalation; incompatible rollback cannot admit |
| P-A10 | Native launchd regression against #865: exact contract lookup, protected-folder negative tests, owner no-prompt confirmation |

Suggested slices: policy authority/migration; runtime adapters/boundaries; denial lifecycle; tray/CLI/readback. Each slice gets its own executable acceptance and supported-platform evidence.
Open: authenticate local grants; external-isolation baseline; host default/migration hold; emergency breach response. Do not implement a security guarantee using only prompt text or same-user file permissions.

Projects-folder and cwd semantics: [S2–S4](setup-and-project-locations.md). Neither the parent-folder preference nor cwd grants access to sibling projects or substitutes for P4 enforcement.

## Contract detail

Moved verbatim from `taskq.md` (#1179) to keep the contract under its R8 size bound. `taskq.md` keeps the decision and links here; this text keeps the same authority (R8, R13).

**Access (R9).** `<install>/worker-policy.json` is operator-owned: `revision` (+1 per write) and `grants`, each `runtime`, preset `mode`, scope (`project` root, else host default; a project grant replaces the default there) and provenance (`by` OS account, `at`). Presets: `restricted` writes runtime homes, user caches, OS temp and `<root>/.taskq`; `workspace` also `<root>`; `full` turns the runtime sandbox off on start and resume (Claude `--permission-mode bypassPermissions`; Codex `-s danger-full-access` without other sandbox options, model and effort kept). Each start and resume resolves requested (`taskq.json` flags) and effective access; `service permissions` and `status.json` `access` show both. No grant: legacy flags run unchanged, never recorded as a grant; only macOS Codex `workspace-write` gains its own Git metadata paths ([shipped enforcement](#shipped-enforcement)). Every mode but Full keeps `<install>` (policy, token, releases), `PATH` directories, the runtimes' package directories and `.codex/*.toml` out of worker writes. Enforcement: macOS a taskq Seatbelt profile; Linux Codex Restricted/Workspace the `taskq-sandbox` launcher ([setup and boundary](linux-sandbox.md)) and an explicit project grant; Windows Codex Workspace unavailable until containment qualification ([qualification matrix](../runtime-qualification.md)); per-platform boundaries in [shipped enforcement](worker-permissions.md#shipped-enforcement). Windows Restricted, read-only narrowing and network-denied requests refuse until qualified; no Full retry or working-installation migration. Unknown enforcement refuses before claim or resume, with the reason in `capacity` `reasons`: unreadable policy, missing launcher prerequisites, no Linux grant, or other OS/runtime without enforcement. Full on the same host and user is uncontained: its worker can edit the policy. Other modes close direct writes only: user autostart, shell or runtime settings and repository Git config or hooks a worker plants and that later run outside a sandbox (the service's own `git` included) stay a same-user path. `service permissions` writes outside a worker only (refused under `TASKQ_ATTEMPT`); a board answer never grants. Changes apply to new starts and resumes. Rollback floor `4.2.0-dev`: with any grant or an unreadable store the service and a grant write set an older `previous` to the running version; a release that fails health then stays down, nothing admitted, for the operator. A manual downgrade below the floor is the operator's and runs legacy flags ([procedure](worker-permissions.md#rollback-floor)).
5. `service install` installs its binary (coreq `install_self`) as a new file, never over an existing release binary in place: macOS kills every later start of a rewritten binary (`OS_REASON_CODESIGNING`), and three such starts roll the release back. It then writes and loads the unit; while the project's fresh `status.json` lists live children (or is unreadable) it writes `<root>/.taskq/restart` instead of reloading, so they pass over as in step 3. Windows `stop`/`uninstall` and a reloading `install` also end the service process tree; stopping a child ends its process tree (`taskkill /T`). On Windows run setup outside an MSIX app (e.g. Claude Desktop): its AppData writes are private, the task sees neither binary nor `gh` login. The unit's coreq launcher counts unhealthy starts per project, so one project's crash loop rolls back `current` and starts of other projects do not count. macOS signing (#1089): with the login-keychain identity `TaskQ Local Signing`, `service install`, an update and the tray sign as `org.taskq.taskq` so one TCC grant matches every later release while `<install>` stays a plain folder (no `Resources` entry, [bundle trap](worker-permissions.md#macos-signing-identity)); without it, or on a failed signature, they stay ad-hoc and the log says so ([procedure](worker-permissions.md#macos-signing-identity)).

### One sandbox per daemon

A runtime with the `background` capability (Claude `--bg`) runs its jobs under one per-user daemon, one per account home. The daemon starts on demand and exits once idle. On macOS each job inherits the daemon's Seatbelt, and Seatbelt can neither widen nor nest, so one daemon serves exactly one grant; jobs of other grants wait or use another runtime.

- Identity. Every taskq Seatbelt profile ends in two `mach-lookup` rules on reserved names `com.taskq.seatbelt.<H>.allow` and `.deny`, with H the SHA-256 of the rest of the profile: lookup allowed on `allow`, denied on `deny`. No service is registered or contacted. These markers leave file access unchanged and need no filesystem objects or path resolution. Two projects with the same limits share H and may share a daemon.
- Readback. `<bin> daemon status` in the job's account home names the live daemon; native `sandbox_check` on its pid queries `mach-lookup` with `SANDBOX_FILTER_GLOBAL_NAME`. A profile job fits only when `allow` is allowed and `deny` is denied. A Full job fits only an unconfined daemon. No live daemon fits any job: this launch starts it under the job's own profile.
- Launch. Start, resume and owner sessions read back and launch under one host-wide lock, so two projects cannot race an idle daemon. A daemon that differs, or a readback that cannot be verified (R12), starts nothing: the launch is held and retried each pass, without replay, migration or a new attempt. taskq never stops a daemon.
- Selection. A waiting runtime refuses admission with `capacity`, so unpinned work takes the next runtime (§ 4) and pinned work waits with the reason in its `Ready` row.
- Drain. The first job that truly waits (a pinned task, held launch or resume) holds new starts of other grants on that daemon, so a busy project cannot keep it alive forever. Resumes of live attempts continue. The hold lapses 10 minutes after that job last waited.
- Status. The service's heartbeat `daemon-sandbox` line and the `Anomalies:` row name each live or unverified daemon that differs from the grant of a live, held or waiting job (A2). A daemon the owner starts by hand between readback and launch can still receive a job; the next pass names it there.

### Known Full cases

Moved verbatim from `taskq.md` (#1325) to keep the contract under its R8 size bound. Known macOS Codex 0.159.3 cases (other versions/platforms unknown):
- Blender 5.2.1 Metal: Workspace exit 139 3/3; Full passes 3/3 ([#157](https://github.com/taskqorg/taskq/issues/157#issuecomment-6029143783)).
- App-server socket client: Workspace EPERM despite socket roots/allowlist; Full connects ([#270](https://github.com/taskqorg/taskq/issues/270#issuecomment-6067173258)); no supervisor role restored.

### Antigravity CLI grants

Antigravity workers and reviewers require an explicit `antigravity` grant in the existing operator-owned policy store. Legacy Claude/Codex requests do not grant it. macOS Workspace/Restricted use the existing Seatbelt boundary, with `~/.gemini/antigravity` and `~/.gemini/antigravity-cli` writable only for its own runtime grant; other operating systems refuse unqualified containment. Full uses only the explicit Full grant and remains uncontained by TaskQ. Workspace and Full pass `--dangerously-skip-permissions` to agy 1.4.12 so headless stream-json turns can execute tools; Workspace retains outer Seatbelt enforcement. Seatbelt denies writes to `.gemini/config/hooks.json` and `.gemini/antigravity-cli/settings.json`, including when a broader writable root contains them.

Executable lookup appends `<home>/.local/bin` through `user_bin_path` when resolving `agy`, preserving PATH precedence. Login detection reports `logged in` when either `~/.gemini/antigravity-cli/jetski_state.pbtxt` or `~/.gemini/oauth_creds.json` is a file; it reads no credential contents. Missing or unobservable credentials remain `unknown`. Credential presence does not prove token validity or a completed native turn (R12).
