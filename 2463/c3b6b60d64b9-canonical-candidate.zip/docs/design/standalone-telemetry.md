# Standalone telemetry

Design for #1185, on the records of #1147 and #1173 and the views of #1174 ([profiling detail](profiling.md)). Owner request: a standalone install records the same telemetry as a connected one, keeps it on the host, sends nothing without serverq, and ships the guide and commands an agent needs to analyze it. The decisions are in [taskq.md § Product](../../taskq.md#product). Everything below that is not marked as shipped is a target; the recommendations await owner acceptance and change no runtime rule (R8, R12, R13).

Standalone means an install with no serverq connection. A connected install is one with that connection; its design is not part of this task.

## Historical log implementation

Facts on main at #1188 (shipped):

- Collection never depends on a connection. Every service and CLI process appends `taskq-profile`, `taskq-stage`, `taskq-board`, `taskq-transition` and `taskq-requests` lines to `<install>/taskq.log` ([§ 4 Profiling](../../taskq.md#profiling)).
- No code sends profile records off the host. The [DashQ connection](enrollment.md) sends no profile record. Incident reports (§ 4) are a separate fault report, not telemetry.
- `taskq profile`, `taskq profile export|tasks|board [--since 30m|24h|7d]` read only that log. They make no board calls.
- Store bound: `taskq.log` past 4 MiB keeps its newest half ([§ 4 Data](../../taskq.md#4-service)). The bound is shared with service text lines, and no retention window is named.

Measured on one Windows host: `taskq.log` held 2.1 MB over 21.5 h. Of about 21,200 records, 20,450 were `taskq-profile` operation lines (mostly `forge.call`); stages were 30, board operations 498, transitions 18. At the 4 MiB bound, a busy host keeps about 1–2 days. A question about the past week reads mostly pruned history.

## Accepted storage change

Owner selected SQLite/WAL for local telemetry. This replaces choice C below; that comparison is historical design context, not the implementation target. SQLite runs inside the product process, with a bundled library on all supported platforms and no server. Keep the existing record definitions, always-on instrumentation and analysis/export commands; JSONL remains the export format. Task state remains on the board (R1).

Retention: 30 days within a 1 GiB installation budget; name and enforce database, WAL and temporary-space bounds in the implementation plan. Reuse the existing service for pruning. Set durability and busy timeouts per [shared data](https://github.com/taskqorg/specq/blob/main/engineering/data.md). An unavailable, full, corrupt or unsupported store reads unknown; instrumentation must preserve the operation. Never reset a corrupt database silently.

## Historical comparison

| Choice | Options and trade-offs | Original recommendation |
|---|---|---|
| Store and retention | A. Keep `taskq.log` at 4 MiB: no code, but about 1–2 days on a busy host, no named window, and text lines compete with records. B. Raise the shared bound (for example 32 MiB): small change, still no window, and the text log grows with it. C. Own profile store: daily JSON-lines files `<install>/profile/<UTC date>.jsonl`, 30 days and 64 MiB, the pruner removes the oldest whole day: a named window per [specq profiling](https://github.com/taskqorg/specq/blob/main/engineering/profiling.md#analysis-export), `--since` reads only the needed files; costs a migration of the readers and the pruner. D. SQLite: the specq default for state, but these are append-only records; adds a native dependency on three OS for no query the views need. | C. Same lock and record lines as today; `taskq.log` keeps service text. At the measured rate (about 1.7 MB a day) 30 days fit the bound; the export header states the retained window. |
| Data path | A. Each consumer reads `taskq.log` itself: couples DashQ, serverq and agents to the log format. B. `taskq profile export` is the one data path; reports, agents, DashQ and a future serverq upload read its JSON lines. | B. The export schema is versioned (`schema` 1); a new column is a new schema version. Reports stay derived views, never a second source of truth. |
| Sending | A. Upload by default when a collector URL is configured: easy to enable by mistake. B. Nothing leaves the host unless the owner connects the install to serverq through an explicit, revocable grant, like the [DashQ connection](enrollment.md). | B. A standalone install has no send code path enabled. Collection, retention and views are identical with or without the connection; the connection only adds an upload of export rows. Its design is a separate task. |
| Guide delivery | A. A page in this repository: a standalone host has no checkout, and a fetched page can drift from the installed binary. B. `taskq profile guide` prints the guide embedded in the binary: offline, matches the installed commands, works in every client. C. Install a skill or instruction file into each client's configuration: triggers by itself, but writes client settings, needs consent per client and per-client upkeep. | B. `taskq help` lists it. The tray operator brief (§ 4 AI requests) names `taskq profile guide` for time, context and cost questions. C stays a later, opt-in option. |
| Money cost | A. Estimate cost from tokens with a built-in price list: prices change and the records carry no model id or output tokens, so a number would be invented (R12). B. Report tokens and model calls only; money reads unknown until stages record the model and output tokens and the owner supplies prices. | B. The guide says "cost: unknown (no model, output tokens or price)" and names gap G3. |

## Analysis guide

`taskq profile guide` embeds the [analysis guide](profile-guide.md). It reads no store, board or network and rejects `--since`.

## Gaps

Each gap is a named follow-up, not part of this task. Numbers are stable.

| Gap | Missing | Proposed fix |
|---|---|---|
| G1 | The bare `taskq profile` refuses `--since`, so stage, transition and service tables cover all retained records only. | Accept `--since` on the bare report, through the export window. |
| G2 | No per-attempt view, and no attempt elapsed time: stages overlap, so summed `us` is not elapsed time, and a span from the rows' end times (`at_ms`) minus durations also counts idle time between stages. | `taskq profile attempts [--since]`: `Project`, `Task`, `Attempt`, `Runtime`, `Coverage` (`complete` or the missing stages), `Elapsed s` (first stage start to last stage end; unknown unless coverage is complete and every row has `us` and `at_ms`), one `<stage> s` column per stage, `Model calls`, `Context tokens`, `Outcome`, from export rows. |
| G3 | Money cost: stage records hold context tokens (input, cache included) and calls. | Stages record `model`, `output_tokens` and the context split `input_tokens`, `cache_read_tokens`, `cache_write_tokens` (#1647) where the runtime reports them, else null with a reason ([stage tokens](profiling.md#stage-tokens)); prices only from owner-supplied config; otherwise cost reads unknown. |
| G4 | Context by source (brief, embedded rules, files, tool output) is not recorded. | Read it from the runtime's own accounting, or agentq's when installed, without a second collector; needs its own design. |
| G5 | Retention: 4 MiB shared bound, no named window. | Accepted SQLite/WAL store above; 30 days within the 1 GiB budget. |
| G6 | Guide command implemented in this change. | Offline embedded analysis guide, named by the operator brief. |
| G7 | Stage rows carry no host (the log's own host), so merged exports from several hosts lose attribution. | Add `host` to stage records, or the export fills it from the install's host name. |

## Session loading

Any agent session on the host (PM, operator or a plain client session) answers a telemetry question in two steps: run `taskq profile guide`, then run the command it names for the question. No skill install, configuration write or network access is needed. Until G6 ships, the session reads this page and uses the table above.

## Acceptance of the follow-up work

A follow-up task is done when, on one host: the guide command prints this table; each question's command prints the named columns or a named unknown; a fixed record set covers the new views in the existing `export_then_reports` chain check; and no profile record leaves the host without a serverq connection (no send call in the standalone path).

## SQLite implementation and transition

Telemetry has one live writer and one source: the coreq capture at `telemetry.log/universal.sqlite3`. Semantic observations go through that writer; there is no second collector.

The 30-day window lives in a 1 GiB installation budget (CoreQ `telemetry::Budget`). Half, 512 MiB, is the working share: universal store 384 MiB, its WAL and SHM 64 MiB, and a 64 MiB peer share for the [retired archive](#retired-archive), its sidecars and `taskq.log`. The other 512 MiB is reserve: checkpoint and pruning run inside it, never normal growth. Each mutation measures peer DB/WAL/SHM and current taskq.log; peer growth never shrinks the universal cap. Capacity pruning starts at 80% of the store cap and works toward 60%, at most 4096 rows per append so a live append never holds `taskq-profile.lock` for a bulk prune (#1321); unchanged polls go last. A full store, an over-share WAL, peer pressure or reserve use reports a degraded state (`database-over-cap`, `wal-over-share`, `peer-share`, `reserve-used`, `capacity-pruned`) and prunes; it never fails the operation. An oversized existing store opens and prunes to 60%. The IPC endpoint binds this budget so a bounded client cannot attach to an incompatible writer. Every periodic producer (service pass, tray tick, CLI) folds unchanged calls into change rows and 15-minute aggregates: identity and status polls, the tray tick's page push, its render (a JS module summary, not an action) and the resize after it. A failed or changed call keeps its rows. An idle hour of six projects plus the tray tick stays under 1/720 of the store cap, so 30 days fit (`six_project_poll_hour_fits_store_budget`).

### Retired archive

The universal store is the only telemetry source. `telemetry.log/telemetry.sqlite3` and telemetry lines in `taskq.log`, left by older releases, stay on disk unread: no reader, importer or report sees them, and no automatic step deletes them. The retired archive and its sidecars still count in the peer share while they exist.

### Incompatible writer compatibility

For the R8 exception in taskq.md § 4, bootstrap first requests the current budget. Only the exact installation-budget mismatch permits a second attempt with the v4.6.19 descriptor (64 MiB total, 6 MiB plus 64 KiB reserved, the same lock and peer paths). CoreQ still validates the protected endpoint, database identity and exact budget. Unknown budgets and wire formats remain refused. The process reports compatibility mode and keeps the single shared export path; no side store or source deletion is permitted. A process started after the incompatible owner exits requests the current budget again. A surviving compatibility client retains its smaller bound until restart.

The second R8 exception is [receipt-degraded Stop](host-service.md#receipt-degraded-stop-r8). The new service advertises Stop protocol 2; healthy receipt-backed requests also accept protocol 1. A failed received receipt with protocol 1 refuses before writing intent, so an old service is never wedged by an unsupported degraded record.

## Remote sync (#1353)

Owner-accepted S1–S5, implemented in `src/telemetry_sync.rs`. Facts it builds on: the only live store is the coreq universal store `telemetry.log/universal.sqlite3`; `coreq::telemetry::Reader` reads one committed snapshot without the writer lock; observations carry stable ids; the coreq [connection client](https://github.com/taskqorg/coreq/blob/main/docs/design/enrollment.md) delivers `/ingest` records (at most 100 records and 1 MiB per call) with per-record receipts, backoff and revoke. ServerQ has no ingest route: it is itself a DashQ connection client. The only existing collector is DashQ.

### Decisions

| ID | Decision | Options | Accepted |
|---|---|---|---|
| S1 | Destination | A. DashQ `/ingest` over the existing TaskQ connection. B. A new ServerQ collector service: new server, new deploy, changes ServerQ from read-only checker to collector. | A. No new server or transport; the serverq-named item becomes a DashQ task (A6). |
| S2 | Grant | A. A separate opt-in schema `taskq-telemetry/1` in the connection request, shown on the approval page; adding it needs a new browser approval (new generation); `taskq disconnect` revokes it with the rest. B. Send under the existing grant. | A. Without the schema in the active grant no telemetry code path runs (A3). |
| S3 | Batch and compression | A. One record per block of export rows: payload `{schema, first, last, rows, bytes, gzip, status}` with `gzip` the base64 gzip of the `taskq profile export` JSON lines (flate2 is already a coreq dependency); `event_id` = `t-` + 32 hex of SHA-256 of installation, first and last row id; at most 512 KiB compressed per record. B. HTTP `Content-Encoding: gzip`: needs a coreq wire minor and DashQ change. | A. No wire change; replays return the stored receipt, so retries never duplicate. |
| S4 | Cursor and pruning | A. Durable cursor `<install>/connection/telemetry.json` (last accepted row position, written atomically after `accepted` receipts). Retention and capacity pruning stay unchanged; rows pruned before upload, and a block DashQ rejects as `expired` (past its retention window), are reported as a counted `gap`, never resent or invented; the cursor moves past them. B. Pruning skips unconfirmed rows: the 1 GiB budget can be exceeded while offline. | A. The store bound holds; sync itself never deletes rows (A4). |
| S5 | Runner | A. One background thread in the host service, started per pass when the grant lists the schema; it opens the Reader, sends at most one batch in flight, follows coreq backoff and `Retry-After`, and never holds the profile or writer lock across network I/O. B. A separate process or scheduler. | A. Capture, CLI and service passes never wait on it; failures are one log line and status fields. |

Implementation details: `taskq enroll <url> --telemetry` adds the schema; enrolling again without it, or `taskq disconnect`, revokes it. Only the universal store is sent. Rows go as their export JSON lines; `first`/`last` are `{seq, id}`. A block holds at most 1 MiB of raw rows, halved until it compresses under 512 KiB; one record per `/ingest` call. A job reads at most 8 blocks from one Reader snapshot, drops the Reader, then sends; it runs at most 30 s, then waits 60 s when caught up and 300 s after a stop. Before each send the cursor stores the block's last seq as `pending`, so a retry after a lost reply rebuilds the same block and event id. The payload `status` is `{backlog_rows, backlog_bytes, gap_rows}` (numbers or null, as DashQ D11 reads them) at the block's first send; the cursor keeps it as `pending_status`, so a retry sends the same payload and DashQ never reads a replay mismatch. A block left pending by an older release goes without `status`. Each release ships `taskq-<version>-telemetry-sync-fixtures.json` (`tests/fixtures/telemetry-sync.json`): rows, records with payload bytes, first/last, status and event id, and replay, mismatch, reject and expired cases; `sender_posts_the_published_fixture` regenerates it with `TASKQ_TELEMETRY_FIXTURE=1`. Each release also ships `taskq-<version>-telemetry-fields-fixtures.json` (`tests/fixtures/telemetry-fields.json`, #2013): every top-level field TaskQ writes with its JSON types, and observations of each kind (full, then nulls with unknown reasons) plus `collector.health`. CoreQ pins this file instead of copying TaskQ's field names; `published_field_fixture_lists_every_taskq_field` fails when a field mapping has no fixture value or the pinned store alters an observation, and regenerates it with `TASKQ_TELEMETRY_FIXTURE=1`. An `expired` receipt adds the block's rows to `gap_rows`, advances the cursor past the block and continues; any other rejected receipt stops sending and keeps the cursor. A store whose newest seq is below the cursor was replaced; sync restarts at its first row (new rows have new ids). DashQ's metadata allowlist refuses a payload string over 256 characters, so DashQ must accept and project `taskq-telemetry/1` blocks before receipts read `accepted`; until then sync reads `stopped (rejected: …)` and keeps every row.

### Status (A5)

`taskq connection status` (line `telemetry:`) and `status.json` `telemetry_sync` (`connection` stays the board delivery string): `state` (`off`, `syncing`, `idle`, `retrying`, `stopped`, `unknown`), `last_synced` (local Unix seconds of the last accepted block), `backlog_rows` (by sequence after the cursor), `backlog_bytes` (raw export bytes; null when the job did not read to the newest row), `gap_rows`, `last_error` (a code, never a credential). `off` also covers another project's service on the same install. An unreadable connection, store or cursor reads unknown with its reason; the cursor file is kept.

### Checks

`telemetry_sync::tests`, against a fake `/ingest` that stores records by event id: no grant, no `/ingest` call; restart resumes from the cursor with no duplicate or missing row; a lost reply repeats the pending event id; `429` (Retry-After) and `5xx` back off with the cursor kept; `401` stops and later jobs read `off`; pruned rows count as `gap` and sync deletes nothing; an unreadable cursor is unknown and kept; a slow server never delays a service pass. The coreq reference server and DashQ projection are qualified in the DashQ task. No deploy to any host without owner approval (A6).
