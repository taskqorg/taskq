# Windows qualification: scope decision required

Candidate `12699ff8eed7d16ac721090654e802648ccc0c63`, task #2463, attempt 6675152222.

Qualification is incomplete. R12/A2 startup parity fails in the candidate, and A4 forbids the source change needed to repair it. No source fix or native relaunch was attempted. The recommended next step is a fix in the owning #2427 deliverable, followed by qualification of its new immutable SHA. Keeping the current SHA preserves the A1/A2 gaps.

## Reviewer findings and current evidence

- Before: the previous Service overlay decoded UTF-8 using the Windows default and rewrote production literals (including ellipsis and FORMATS). After: the corrected overlay uses explicit UTF-8; removing its test additions restores every original byte. All 685 canonical Git blobs match. Only four test-related files differ; the changed module visibility is itself guarded by cfg(test). See source-proof.json and corrected-test-only.patch.
- The earlier archive had CRLF-only differences in 621 files. This build reconstructed the candidate from Git blob objects, verified each object identity, and retained a canonical archive privately. No production expressions are modified in the corrected build.
- Corrected Windows test executable build passed. Pinned lint passed with two existing COMPACT warnings. Full checks and paid probes were not rerun after the decisive startup failure.
- startup_parity_2463 asserts equality for every pair, including admission. It FAILS: all four runtimes omit the first local execution row while the heartbeat contains it. The next pass matches in all four. Every pair is retained in startup-receipts.json; none is dropped or counted healthy.
- The existing execution_heartbeat_is_fenced_visible_and_never_reopens_terminal guard PASSES. It checks after two passes, so its pass does not cover the first-admission defect.
- Source readback explains the mismatch: Service.pass_inner builds its snapshot from pre-admission views; admission creates the execution afterwards; Service.pass updates only rows already present. Heartbeat serialization sees the new observation, whereas status_report consumes the old snapshot. This is a source-level diagnosis supported by the fixture reproduction, not fresh native qualification.
- Antigravity's earlier native stream has init, step_update and result events, but no full prompt echo. Exact literal native input remains unknown under A1. Its session, completion and canary receipts do not replace that missing evidence. No assertion was weakened and no uncertain input replayed.

## Acceptance and preservation

A1: incomplete; previous native evidence retained as historical, Antigravity exact native input unknown.

A2: fails at startup; first native attempt had 39/43 equal pairs. Current corrected test-only fixture reproduces four first-pass failures and four second-pass equalities. No production or installed-service qualification claim.

A3: no native launches in this attempt; no grant, login, model, effort or capacity changes; no process stop or replay. Prior action-time grants and client identity receipts are retained as historical evidence, not fresh authority for a future launch.

A4: assigned branch/worktree remains clean; all instruments, builds and evidence stay outside Git. No rebase, push, PR, install or production service change. This archive accompanies the required scope ask; result --file is deferred until qualification can finish or the owner accepts an incomplete handoff.

Applied R2: one worker and no delegated task work. Applied R5: write the concrete conflict and evidence to #2463 with taskq ask. Applied R9: preserve authority and unrelated sessions. Applied R12: failing and unknown evidence remain gaps. Applied R13/section 7: ask before a remedy outside A4. No rules amended.

Raw native logs, credentials, local absolute paths, executables and private build logs are excluded. Artifact and private-log hashes remain receipts. Prior evidence is explicitly prefixed previous- and does not qualify the corrected artifact.
