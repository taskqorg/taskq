# Corrected Windows candidate: source fix and bounded qualification

Task #2463, attempt 6675152222. Candidate `ee39a45cdaf50f9ebc9d4de3c9a8fc92118b2e34` is pushed on taskq-2427 and read back as the head of existing PR #2461. It directly descends from `12699ff8eed7d16ac721090654e802648ccc0c63`; no history was rewritten.

## Correction and evidence

The startup snapshot now receives the newly admitted execution, with its actual runtime and role, before the external launch. The ordinary post-pass overlay still computes the execution verdict and progress; admission, input handling, grants, release and lifecycle authority are unchanged. Only src/service.rs and src/service_tests.rs changed. No rule or guarding assertion was weakened.

Before: the retained startup_parity_2463 reproduction failed on 12699ff8: all four first-pass pairs omitted the local execution, while four second-pass pairs matched. After: the same reproduction passes on the corrected source. The permanent four-runtime guard now checks both passes and retains its unknown, cancellation, fencing, lost-response and terminal-delivery assertions.

The selected canonical gate passed in 776.609 seconds within its 900-second bound, with no retries: 1072 unit tests and 20 integrations passed, alongside offline selftest, Node and artifact/release-script checks. Existing COMPACT warnings remain. Raw private logs are retained and hashed in checks.json. A release-publisher fixture intentionally prints a lock-unavailable error before its successful refusal assertions; the gate exit is zero.

The fresh native Service probes passed for Claude, Codex, codex-app and Antigravity: 52/52 paired projections match after excluding only observation times and process_id. Every captured startup, running and terminal pair is attached; none is dropped. Each runtime records one accepted launch and confirmed Exit release. The instrument now asserts every pair, rather than the earlier at-least-one-pair assertion.

## Acceptance boundaries

- A1: eight earlier start/resume turns are retained as previous-* evidence. Runtime/input code, dependency pins and installed client versions are unchanged; the reconciled instruction requested only invalidated qualification to rerun. These are historical receipts for the unchanged boundary, not newly dispatched turns. Antigravity exact literal native input remains unknown: its native stream has no full prompt echo. Producer serialization, session-bound acceptance, canary replies and completion are separate observations.
- A2: all four fresh native-client Service projection probes pass on the new source. This is the supplied #2453 method: an in-process candidate Service with a fixture board and native clients. Installed-service identity, real-board transport, native containment and telemetry delivery remain unqualified. No production service was changed to manufacture evidence.
- A3: operator revision 6 was read at each new launch and resolved by the candidate's access resolver. The existing Full grants remain uncontained. Each turn has a 180-second bound. No new grants, login, model, effort, capacity changes or uncertain-input replay occurred. Each observed new scope ended; preservation.json records policy/config and original app-process readback.
- A4: the narrow source correction and publication follow accepted owner answer 6675302591 and PM reconciliation 6675391731. The Mac writer explicitly confirmed read-only ownership before writes (checkpoint 6675448889). Earlier commits, native receipts and evidence were preserved. The only tracked change is the two-file correction; temporary instruments and this archive remain outside Git. No new PR, rebase, install or production service control occurred.

## Source and artifact identity

All 685 canonical Git blobs were verified before the temporary overlay. Removing its test-only additions recovers every original byte, including UTF-8 literals. The overlay is confined to cfg(test) modules/re-exports in four files. See source-proof.json and corrected-test-only.patch. The paid instruments are development test artifacts; their archive has no .git and its embedded revision is unknown. Git blob identity, the exact test-only delta and artifact SHA-256 establish their source externally.

The existing PR remains open. Merge-result merge_group CI was not waited for or claimed green; publication to a branch is not merge, deployment, or complete runtime qualification. #2427 retains its remaining A7/A8 work and the Mac evidence reconciliation.

Applied R2: coordinated one writer and preserved the other attempt. R5: attach this evidence through result --file. R9: action-time authority, no policy changes. R12: exact-source proof, before/after failure receipts, native and fixture boundaries, explicit gaps. R13/section 7: apply the accepted narrow correction without amending decided behavior. No rules amended.

This archive excludes raw native transcripts, credentials, absolute private paths and executables. Hashes are receipts for retained private artifacts; they do not publish those artifacts.
