# Windows qualification of #2427 candidate

Candidate: `12699ff8eed7d16ac721090654e802648ccc0c63`. Task #2463, attempt 6674672027.

The bounded native start/resume checks passed for all four runtimes. Full qualification is incomplete: each Service probe's first local snapshot omitted the execution already present in heartbeat readback. The following 39 paired reads match after excluding only observation times and process_id. The first four mismatches remain in the sample files.

## Acceptance and scope

| Item | Evidence | Outcome |
|---|---|---|
| A1 | Four native manifests, eight accepted start/resume turns; same session; native terminal and confirmed exit; matching native and TaskQ canary replies | Native probes pass. Antigravity does not echo the literal prompt: full native input byte readback remains unavailable. |
| A2 | Four native Service probes, source/artifact/client/OS identities, every paired execution projection | Gap: first snapshot missing for every runtime. The next 39 pairs match. |
| A3 | Candidate access resolver runs at every start/resume and Service launch; per-probe authority readback; 180-second turn limits; native releases and preservation readback | Observed pass within the named scope. No uncertain input replayed. |
| A4 | This sanitized archive; source manifest; temporary patch; preservation receipt | No tracked source change, rebase, push, PR, production service control or installation. |

| Runtime | Client | Start + resume | Service probe | Projection equality |
|---|---|---:|---:|---:|
| Claude | 2.1.318 | 35.906 s | 17.625 s | 8 / 9 |
| Codex | 0.162.1 | 18.485 s | 10.531 s | 9 / 10 |
| codex-app | OpenAI.Codex 26.1029.7803.0; CLI 0.162.1 | 48.797 s | 18.672 s | 14 / 15 |
| Antigravity | 1.5.1 | 20.140 s | 9.469 s | 8 / 9 |

The Service is the candidate's in-process Service with a fixture board and real native clients. Snapshot readback is its local execution projection; heartbeat readback passes through the board snapshot reader. No live board task was dispatched by these probes. No installed candidate service, restart recovery, real-board transport, Workspace containment, or full runtime suite is qualified here. This is the supplied #2453 method, not an installed-service claim (R12).

The first local projection is null. Heartbeat reports unknown for Claude and waiting for the other runtimes. Each subsequent pair is equal apart from observation times and process_id. A passing instrument result alone does not prove A2: its inherited assertion requires at least one equal pair. This report independently compares and retains every pair.

## Identity and method

Windows 11 Pro, 10.0.26300, x86_64. See identity.json for tools, executable and loader SHA-256, and policy/config hashes. Native evidence was not reused from older #2451/#2453 candidates.

The pushed taskq-2427 source was fetched and the named immutable SHA archived. Every one of its 685 tracked files matched before building. The unmodified candidate's test executable was preserved as original-test.exe. A second test executable adds only the temporary Service instrument. The Git archive has no .git, so its embedded revision is unknown; the archive/file manifest and executable hashes establish source/artifact identity externally. These are development test artifacts, not released binaries.

Temporary instrument changes appear in windows-service-instrument.patch. Only four test-related files differ; their line endings were normalized in the disposable source snapshot. The supplied v2 method uses a Windows fixture host name, saves every projection and the input/transcript evidence, reads codex-app replies from the native rollout rather than the handshake log, asserts native acceptance and Exit release, and polls owned cleanup for at most 15 seconds if its 180-second bound expires. No bound expired. No macOS compile overlay was used. Production code expressions and runtime policy are unchanged.

The original native check is native_trait_start_resume_and_transcript. The adapted check retains native_service_observation_2453. Both ran separately for claude, codex, codex-app and antigravity with --ignored --nocapture --test-threads=1. Each invocation uses the existing registered grant root and current installed authority store; no store was copied or changed. The ignored checks remain separate from ordinary fixture tests.

Two original candidate fixture checks also passed: execution_heartbeat_is_fenced_visible_and_never_reopens_terminal and trait_launch_preserves_input_policy_environment_and_exit. The latter validates literal input serialization, including Antigravity's JSON content. Neither fixture alone qualifies native behavior.

## Native observations and limits

Native receipts include exact expected input SHA-256 and hashes of the private native transcripts. Claude, Codex and codex-app transcripts contain the literal prompts. Antigravity exposes session-bound step_update/result events and fresh canary replies, but does not echo the outbound full prompt; literal native input echo is unknown, not a passing native byte comparison. Its producer serialization fixture and native stream observations are separate evidence.

Claude and codex-app native turns return 0. Codex and Antigravity return -1 after native terminal events and candidate-requested stops of their lingering owned scopes. The terminal event and independent scope exit are distinct observations. Every Service manifest records accepted=true, one launch and Some(Exit); the three captured native process incarnations were absent at final readback. codex-app has no process identity after its handshake; its exact accepted turn and completion are read from its native rollout. Initial progress without supported events stays unknown; later quiet rows are preserved.

The isolated fixture install has no telemetry collector. It reported telemetry append failures as unknown; telemetry delivery is unqualified. Raw native logs, system prompts, credentials, local absolute paths and executables are excluded. Native transcript hashes are receipts, not a publication of private transcripts.

## Authority and preservation

Applied R2: one assigned worker/attempt; isolated disposable source, no task migration or delegated task work. Applied R9: operator revision 6 was read at each launch; all four effective grants are Full and uncontained. Host flags, model defaults and optimizer inherit behavior were kept. Claude/Codex/codex-app reported inherited optimization on; Antigravity reported off because not attached. No model, effort, permission, capacity, login or integration setting was changed.

There were twelve canary turns plus the codex-app handshake turns. Every probe completed, with no uncertain replay or pending cancellation. Only three input files whose whole contents exactly matched this run's generated prompts were removed. Native qualification conversations remain in client history. All 15 pre-existing app process incarnations survived. Policy, host config and project config hashes match before/after; the assigned worktree remains clean at 49acb093929ed0bc4db0f4a1722b5465bdb83805. Temporary project Full grants remain unchanged; the completed probe scopes no longer need them.

Applied R12 and section 7: no full qualification claim, no installed-service or release claim, no CI claim. The canonical full gate was not run because A4 authorizes evidence only and no source deliverable. Applied R5: submit this archive through result --file, explicitly naming the gaps. No rules amended.

## Build failures and recovery

Before: cargo test --locked --bin taskq --no-run failed with rustc-LLVM out of memory and 0xc0000409. After: CARGO_INCREMENTAL=0 cargo test --locked --bin taskq --no-run -j 1 passed on the unchanged source; the instrument build also passed with the same settings. Build logs are retained privately and hashed in build-evidence.json.

Before: launching the copied test executable without its loader exited immediately with 0xC0000135; no test or paid input ran. After: placing the build dependency's x64 WebView2Loader.dll beside the unchanged executable allowed the fixture and all native probes to pass. The loader hash is in identity.json. This does not qualify installed GNU packaging.

The pinned contract lint passed before other checks, with two COMPACT warnings (56228 bytes versus 55910 target; 274 lines versus 273 target). Dependencies were prepared with npm ci --ignore-scripts --no-audit --no-fund. Existing compiler warnings were retained. No source fix or assertion weakening was made to turn these observations into a pass.
