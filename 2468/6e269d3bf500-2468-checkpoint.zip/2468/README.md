# Guarded evidence-only completion

Implements [#2468](https://github.com/taskqorg/taskq/issues/2468) and the owner's [accepted #2466 choice](https://github.com/taskqorg/taskq/issues/2466#issuecomment-6677793683). Amended rules: R5, R13 and §7. Evidence delivery keeps the tested source identity without publishing that source. It does not qualify another task's native acceptance.

## Failure and retained protection

Before: [#2462 publication-blocked 6675033831](https://github.com/taskqorg/taskq/issues/2462#issuecomment-6675033831), repeated at 6675134520, rejected candidate `12699ff8eed7d16ac721090654e802648ccc0c63` because there was no task PR. Its accepted scope forbids that PR. [Report #2466](https://github.com/taskqorg/taskq/blob/main/docs/research/2466.md) records the previous unsupported route and its limitations.

After: production dispatch selects an evidence outcome only from a trusted immutable owner authorization audit. Initial close, saved publication and action-time close recheck exact result entry/candidate, task scope/type, outcome entries, baseline, attachment identity and owner gates. No authorization retains ordinary source publication. An invalid authorization refuses instead of falling through to a source adapter. Code/unknown/multiple types cannot be authorized.

The authorization has its own stable operation ID. Completion has a deterministic operation ID and uses the existing revision-fenced close/write readback. A lost close response rebuilds Closed from board entries; a restarted service projects that close without a second receipt or agent execution. The summary links an evidence-only receipt and its candidate. Source readiness remains unknown without independent publication evidence; no deploy-waiting label is produced.

A first stale-case fixture failed because its synthetic unbound `ask` was ignored by fold. The retained fixture now creates a reviewer-bound question (or a pending-publication blocker), asserts Ask then Review, and verifies rejection of the old authorization. Accepted notes also invalidate authorization even when the attempt revision stays unchanged. No existing gate or CI assertion was weakened.

## Source provenance and compatibility

The ordinary proof is a clean owned task worktree with a branch-creation baseline and no source delta. A missing, changed or unreadable workspace is unknown, never assumed clean.

For checkout-free evidence work, the owner explicitly selects a ZIP source record with `--source-record`. It must contain exactly one `source <candidate> dirty= 0` line, and candidate must equal the authorized baseline. The ZIP directory/local header, member identity, size, CRC and SHA-256 of the complete attachment are verified. Selected records are bounded at 64 KiB; unsupported/encrypted/streaming/ZIP64 archives refuse. Members are read in memory and never extracted or executed. An existing task workspace still must pass the worktree check. This freezes the archived observation, not current native health.

Update every board reader before using `taskq evidence`. The owner's `--readers-current yes` explicitly confirms that cutover; old folds ignore the audit, while old publication reconcilers cannot select this route. Existing results and candidates are never rewritten. Satisfy any owner gate first, then authorize the current outcome. A new question, note, scope/result change or altered evidence requires fresh authorization.

## Executable evidence

`cargo test --locked --bin taskq evidence:: -- --test-threads=1` covers these boundaries with bounded real Git observations and a substituted board:

- Initial and saved completion, lost close response, restart through the service with a launcher that panics on any agent launch, exactly one close and zero source publication calls.
- Changed/missing bytes, wrong candidate/baseline, unknown/code type, changed scope, dirty worktree, edited/malformed authorization, changed outcome/notes, required/stale owner gates and unauthorized callers.
- Committed source changes refuse even when the candidate is explicitly named.
- Checkout-free clean-source records complete; missing/corrupt/oversized/truncated/dirty/wrong-source records refuse without creating a checkout.
- Accepted result identity stays proven while source readiness stays unknown, and evidence completion produces no source deployment claim.

Existing board merge-queue/private exact-SHA fixtures, gate/golden traces and the canonical selected gate remain required. Linux development outcomes: evidence fixtures 4 passed (the snapshot instrument excluded by default); the explicitly supplied #2462 snapshot instrument passed separately, one receipt and zero source publications. The first snapshot run completed but its diagnostic assertion incorrectly read publication from Closed, where fold clears that field; the retained check resolves the close verdict through its publish receipt. Final canonical/board outcomes are on the task handoff. Fixtures establish adapter/model/process connections, not native client behavior or a live board deployment.

## #2462 checkpoint

Only after the new completion fixtures passed, read back #2462 and download its immutable attachment. The board still records an open asset task in Ask with the same result and saved reviewer verdict. No live task state, candidate, branch, PR, service or native execution was changed.

Verified attachment:

- URL: [Mac evidence](https://github.com/taskqorg/taskq/raw/1d585528371cda28cdb571e6acd167b3b20a3848/2462/b2d942f439bf-taskq-2462-mac-evidence.zip).
- Bytes: 28,109; SHA-256 `b2d942f439bff45ec87e1468e0e1c7aba3052f90af98f529e5cc5f341b7c715d`.
- `summary.json`: candidate `12699ff8eed7d16ac721090654e802648ccc0c63`; exact clean clone with no overlay.
- Source member: `taskq-2462-mac-evidence/identity-before.txt`, containing `source 12699ff8eed7d16ac721090654e802648ccc0c63 dirty= 0`.
- Exact test binary SHA-256: `f2d22bf6e15f38b5cf92a5fad25ed0f97bc964e9e0649ed537647d83106a7b89`.

The opt-in `evidence::tests::evidence_2462_snapshot_checkpoint` reads the sanitized board JSON and archive supplied through `TASKQ_EVIDENCE_SNAPSHOT` and `TASKQ_EVIDENCE_ARCHIVE`. It replays only board responses in memory through production authorization and reconciliation, using a simulated owner answer/authorization. It verifies the exact candidate/archive, one completion receipt, zero source publication calls and retained limitations. This is not a live owner authorization or a native replay.

After reader adoption, the owner can resume #2462's pending outcome, read its fresh revision, and authorize this exact candidate/baseline, URL, SHA-256 and source member through `taskq evidence`. The worker cannot grant that authority or close another live task (§7). The existing free-text retry answer is not converted into an authorization.

All #2466 limitations remain: fixture-board service observation, not installed-service qualification; read-1 status/heartbeat lag for all runtimes; no codex-app process identity; six untraced process_id rows; Claude exit-to-release not excluded; Antigravity transcript not independently reread by its reviewer, only test assertions. This publication change does not prove A7 of #2427.

Contract lint passes under the hard caps but reports the 70% working targets. The required compaction follow-up is [#2470](https://github.com/taskqorg/taskq/issues/2470), read back held and not admitted. No cap or target changed.

## Refactor reconciliation

The reviewer reproduced a merge conflict against `cbd4286ff125e4a46ac5c36d55dfaa80cacc0360` in dispatch, main and summary. Rebasing preserved the typed delivery policy, moved evidence help/argument parsing into `cli.rs`, and resolved summary's relocated inbox reader. The first compile then rejected the gate fixture's old string delivery value (E0277); it now uses `Delivery::ReviewPr`, retaining the same approval refusal assertion. No gate assertion or completion authority changed. Candidate-specific check outcomes are recorded in the task handoff.

The refactor gate initially refused the tracked evidence directory. This report is now delivered as an attachment outside the source tree under the current docs/testing.md policy.

Final rebased candidate `4bcc5356`: `python3 scripts/check.py` PASS, Linux, 246.214s; 995 unit tests passed/41 ignored, 22 integration passed/1 ignored, offline selftest and Node/script checks passed. Full run used a temporary writable Cargo cache because the host cache is read-only in this sandbox. Diagnostics reported unavailable telemetry on some fixture paths; all test assertions and the staged telemetry capture passed. Contract COMPACT warnings remain tracked by held #2470.

After that gate, fresh #2462 board/archive snapshots passed `cargo test --locked --bin taskq evidence_2462_snapshot_checkpoint -- --ignored --nocapture`: exact candidate/archive, one receipt, zero source publication, no native replay or live board writes. General evidence fixtures: 4 passed/1 opt-in ignored. Merge-group CI remains unverified at worker handoff.
