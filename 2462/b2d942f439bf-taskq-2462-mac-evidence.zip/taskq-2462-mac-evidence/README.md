# #2462 Mac evidence for #2427 A7

Candidate: 12699ff8eed7d16ac721090654e802648ccc0c63, exact clean clone with no overlay. No Git object, branch or service changed.
Machine data: summary.json. Raw native logs stay out; each has a SHA-256 in summary.json.
Client and OS: macOS 27.2 (26B123) arm64, Claude 2.1.318, codex-cli 0.159.3, agy 1.5.1, ChatGPT app with bundled Codex CLI. Artifact hashes: instrument-identity.txt.

## #2453 gaps re-checked
- Exact tip build on macOS: closed. The candidate compiles with no overlay; the start and resume binary is the exact source.
- Runtime tests depend on the environment: closed for python and TMPDIR. runtime:: 145 passed, 0 failed, 17 ignored with no python shim, cleared probe environment and a non-symlink TMPDIR (runtime-suite-no-shim.txt). A TMPDIR under the /tmp symlink was not re-run.

## A1 Native start, resume, transcript
Test native_trait_start_resume_and_transcript on the unpatched exact binary (runs/<runtime>-run.txt).
Claude, Codex, codex-app and Antigravity each passed two bounded turns: start, resume, same session, exact input accepted, fresh canary in the native and the TaskQ transcript.
Exit: Claude 0, codex-app 0. Codex and Antigravity -1 after the native turn end, because TaskQ stops the lingering owned process.

## A2 Status and heartbeat
Instrument: native_service_observation_2453 (service-observation-instrument.patch, temporary, not in #2427, different binary hash). It runs the candidate Service pass on a fixture board with a real native client and one real bounded turn.
Each runtime reached a running row in status and heartbeat readback, then released Exit, one launch, canary in the native and the TaskQ transcript.

| Runtime | Reads | Equal | Unequal | Running reads | Status rows with process_id | Native identity |
| claude | 6 | 5 | 1 | 5 | 5 | pid 60984 |
| codex | 7 | 6 | 1 | 6 | 6 | pid 77509 |
| codex-app | 13 | 12 | 1 | 3 | 6 | none |
| antigravity | 8 | 7 | 1 | 5 | 7 | pid 79218 |

Comparison strips only: row observed, process_id, progress observed, last_event, deadline, overdue_since and tool_since.
All other reads are equal. The one unequal read in each runtime is read 1: the Service read model has no row yet while the heartbeat already shows waiting. The next pass agrees. So status lags the heartbeat by one pass at launch; this is recorded, not excused, and summary.json holds each pair.

Instrument changes from #2453, outside Git:
- Reply check reads the native transcript through native_session and worker_transcript, not the launcher log. This removes the #2453 codex-app false failure. All four tests passed first time; no turn was repeated.
- Parity counts every read and keeps unequal pairs, instead of counting matches only.
- Records the heartbeat execution lines, launch time, ps start of the reported process, and TaskQ transcript reply.
- "Status" here is the Service read model that status.json serializes (service.rs snapshot). No status.json file was read, because the instrument does not run the CLI service wrapper.

## Named gaps
- Not installed service: the installed Mac service stays 4.6.84-261105-1, pid 1106 (identity-after.txt). Nothing here claims installed-service behavior of the candidate. Board is a fixture; native clients are real.
- Fixture execution_heartbeat_is_fenced passed on the exact binary and qualifies nothing native (fixture-heartbeat.txt).
- codex-app: still no native process identity. Progress stays unknown ("no supported native progress event"). New against #2453: 6 of its status rows carried a process_id. The instrument does not record which rows; the first running row printed has none. Their source is not traced (service.rs live_pid); the launch handshake process is the likely source, unverified.
- Claude reported process: resolved. Identity start equals the ps start of "claude bg-spare", 498 seconds before launch: the reported process is the pre-warmed daemon spare. Only this one run shows it.
- Claude exit to release: not reproduced and not excluded. #2453 saw unknown there. This run went waiting, running, then released, with no unknown row at 1 second samples taken after each pass; a state inside one pass is invisible to this instrument.
- Antigravity went from waiting straight to running with quiet progress; Claude and Codex showed running with unknown progress first. Timing only, one sample each.

## A3 Authority and preservation
Grants were read at each launch; policy revision 34 (permissions-before.txt, summary.json). Claude legacy, no grant. Codex workspace. codex-app full, uncontained, owner grant. Antigravity workspace.
worker-policy.json and host.json hashes are unchanged after all runs. No grant, login or policy changed.
Paid approval: #2427 note 6664768263. 12 short turns, each bounded at 180 seconds. No uncertain input was replayed; each turn has its own canary.
The service pid and the ChatGPT app processes 543 and 73225 kept their pids. Unrelated sessions were not stopped; the Claude daemon was not restarted.
Cleanup: 3 probe input files were removed from the project .taskq/inputs, found by canary. Native sessions named TaskQ Qualification stay in the clients' history.
